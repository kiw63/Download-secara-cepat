import {captureStill, downloadBlob, readableBytes, renderFrame, localEnhance, videoMime, createRecorder} from './media.js';
import {enhanceOnDevicePhoto} from './ondevice-ai.js';
const $=id=>document.getElementById(id);
let token=localStorage.getItem('blink.session')||'', user=null, stream=null, facing='environment', frameLoop=0, recorder=null, videoOutput=null, processedPhoto=null, originalPhoto=null, livePhoto=null, liveMotion=null, chosenPlan=null, isBusy=false, activeCaptureFps=0, activeAudio=false, renderFrameCount=0, lastFrameMeasure=0;
let apiRoot=localStorage.getItem('blink.api')||window.BLINK_API_BASE||'';
function toast(m,error=false){const e=$('toast');e.textContent=m;e.className='toast show'+(error?' error':'');clearTimeout(toast.timer);toast.timer=setTimeout(()=>e.className='toast',5500)}
function status(id,m){$(id).textContent=m}
function showScreen(name){document.querySelectorAll('body>.screen').forEach(el=>el.classList.toggle('show',el.id===name))}
function navigate(name){document.querySelectorAll('.page').forEach(el=>el.classList.toggle('active',el.id==='page-'+name));document.querySelectorAll('.bottomnav button').forEach(b=>b.classList.toggle('active',b.dataset.view===name));if(name==='plans')void loadPlans();if(name==='payment')void refreshOrders();if(name==='account')refreshAccount(); if(name==='camera'&&stream)$('camera-feed').play().catch(()=>{});}
async function api(path,{method='GET',body,auth=true}={}){
  if(!apiRoot.startsWith('https://')&&!/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(apiRoot)) throw Error('Server BLINK belum dikonfigurasi dengan alamat HTTPS yang valid.');
  const head={'Content-Type':'application/json'};if(auth&&token)head.Authorization='Bearer '+token;
  let res;try{res=await fetch(apiRoot.replace(/\/$/,'')+path,{method,headers:head,body:body===undefined?undefined:JSON.stringify(body)})}catch{throw Error('Tidak tersambung ke server BLINK. Periksa internet dan alamat server.');}
  const data=await res.json().catch(()=>({}));if(!res.ok)throw Error(data.detail||`Layanan gagal (${res.status})`);return data;
}
function updateWallet(){const balance=user?.tokens??'—';$('tokens').textContent=balance+' token';}
async function checkRealESRGAN(){
  const option=[...$('photo-quality').options].find(o=>o.value==='real-esrgan');
  if(!option)return;
  option.disabled=true;
  try{
    const st=await api('/api/ai/status',{auth:false});
    if(st?.trained_model_ready && st.engine==='RealESRGAN_x4plus'){
      option.disabled=false;option.textContent='Real-ESRGAN x4 Server — Ultra 4K';
    }else{option.textContent='Real-ESRGAN x4 Server — menunggu bobot asli';}
  }catch{option.textContent='Real-ESRGAN x4 Server — server AI belum terhubung';}
}

async function refreshMe(){if(!token)throw Error('Belum login');user=await api('/api/me');updateWallet();return user}
async function enterApp(){
  if(token){try{await refreshMe();showScreen('studio');navigate('camera');void checkRealESRGAN();void startCamera().catch(e=>toast('Izinkan kamera agar BLINK dapat mengambil foto: '+e.message,true));return;}catch(e){if(!String(e.message).includes('tersambung')){token='';localStorage.removeItem('blink.session');}toast(e.message,true)}}
  showScreen('auth');
}
$('enter').onclick=()=>void enterApp();
$('show-register').onclick=()=>{$('login-form').hidden=true;$('register-form').hidden=false;status('auth-title','Daftar Akun BLINK')};
$('show-login').onclick=()=>{$('login-form').hidden=false;$('register-form').hidden=true;status('auth-title','Masuk ke BLINK')};
$('register-form').onsubmit=async e=>{e.preventDefault();try{await api('/api/auth/register',{method:'POST',body:{name:$('reg-name').value,email:$('reg-email').value,password:$('reg-pass').value},auth:false});toast('Akun berhasil dibuat. Silakan masuk.');$('login-email').value=$('reg-email').value;$('show-login').click()}catch(err){status('auth-status',err.message)}};
$('login-form').onsubmit=async e=>{e.preventDefault();try{const result=await api('/api/auth/login',{method:'POST',body:{email:$('login-email').value,password:$('login-pass').value},auth:false});token=result.token;localStorage.setItem('blink.session',token);await refreshMe();$('login-pass').value='';showScreen('studio');navigate('camera');void checkRealESRGAN();void startCamera().catch(e=>toast('Izinkan kamera agar BLINK dapat mengambil foto: '+e.message,true))}catch(err){status('auth-status',err.message)}};
$('logout').onclick=()=>{if(token)void api('/api/auth/logout',{method:'POST'}).catch(()=>{});token='';user=null;localStorage.removeItem('blink.session');stopCamera();showScreen('auth');$('show-login').click();toast('Kamu sudah keluar.')};
$('server-url').value=apiRoot; $('auth-server-url').value=apiRoot; $('auth-server-save').onclick=()=>{const v=$('auth-server-url').value.trim().replace(/\/$/,'');if(!v.startsWith('https://')&&!/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(v))return status('auth-status','Alamat server harus HTTPS.');apiRoot=v;localStorage.setItem('blink.api',v);status('auth-status','Server berhasil disimpan.');};
$('server-save').onclick=()=>{let v=$('server-url').value.trim().replace(/\/$/,'');if(!v.startsWith('https://')&&!/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(v))return toast('Masukkan alamat HTTPS server BLINK.',true);apiRoot=v;localStorage.setItem('blink.api',v);toast('Alamat server tersimpan.');void refreshMe().catch(e=>toast(e.message,true))};
function refreshAccount(){if(!user)return;$('account-info').textContent=`${user.name} (${user.email}) • ${user.tier.toUpperCase()} • ${user.tokens} token tersedia`;$('server-url').value=apiRoot; $('auth-server-url').value=apiRoot; $('auth-server-save').onclick=()=>{const v=$('auth-server-url').value.trim().replace(/\/$/,'');if(!v.startsWith('https://')&&!/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(v))return status('auth-status','Alamat server harus HTTPS.');apiRoot=v;localStorage.setItem('blink.api',v);status('auth-status','Server berhasil disimpan.');};}
for(const b of document.querySelectorAll('[data-view]'))b.onclick=()=>navigate(b.dataset.view);
$('upgrade').onclick=()=>navigate('plans');$('back-studio').onclick=()=>navigate('camera');$('back-plans').onclick=()=>navigate('plans');

// Camera is the primary media source. Android requests CAMERA permission when this API runs.
async function startCamera(audio=false){
  if(recorder?.state==='recording')throw Error('Hentikan rekaman sebelum mengganti kamera.');
  const requestedFps=$('video-fps').value==='60'?60:30;
  if(stream&&stream.active && Boolean(stream.getAudioTracks().length)===Boolean(audio) && activeCaptureFps===requestedFps)return stream;
  stopCamera();
  const fps=requestedFps;
  const video={facingMode:{ideal:facing},width:{ideal:3840},height:{ideal:2160},frameRate:{ideal:fps}};
  try{stream=await navigator.mediaDevices.getUserMedia({video,audio})}
  catch(error){if(error.name==='OverconstrainedError'||error.name==='NotReadableError'){stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:facing}},audio})}else{status('camera-status','Izin kamera diperlukan: '+error.message);throw error}}
  const v=$('camera-feed');v.srcObject=stream;await v.play();const extra=$('video-feed');extra.srcObject=stream;extra.play().catch(()=>{});$('camera-empty').hidden=true;$('video-placeholder').hidden=true;
  activeCaptureFps=fps; activeAudio=Boolean(stream.getAudioTracks().length);
  const cfg=stream.getVideoTracks()[0].getSettings();$('cam-info').textContent=`${cfg.width||v.videoWidth}×${cfg.height||v.videoHeight} · ${Math.round(cfg.frameRate||0)} FPS`;
  $('snap').disabled=false;$('video-record').disabled=false;
  status('camera-status',`Kamera aktif ${cfg.width||v.videoWidth}×${cfg.height||v.videoHeight} @ ${Math.round(cfg.frameRate||0)} FPS. Ketuk tombol foto untuk memproses otomatis.`);
  startFrames();return stream;
}
function stopCamera(){activeCaptureFps=0;activeAudio=false;if(frameLoop)cancelAnimationFrame(frameLoop);frameLoop=0;if(stream){stream.getTracks().forEach(t=>t.stop());stream=null}$('camera-feed').srcObject=null;$('video-feed').srcObject=null;$('camera-empty').hidden=false;$('video-placeholder').hidden=false;$('snap').disabled=true;$('video-record').disabled=true}
$('camera-start').onclick=()=>void startCamera().catch(e=>toast(e.message,true));$('camera-stop').onclick=stopCamera;
$('flip').onclick=()=>{if(recorder?.state==='recording')return toast('Hentikan rekaman sebelum mengganti kamera.',true);facing=facing==='environment'?'user':'environment';void startCamera().catch(e=>toast(e.message,true))};
$('video-init').onclick=()=>void startCamera().catch(e=>toast(e.message,true));
function selectedFilter(){const p=$('video-preset').value;return p==='natural'?[]:[p]}
function startFrames(){
  if(frameLoop)cancelAnimationFrame(frameLoop);
  const tick=()=>{if(!stream)return;frameLoop=requestAnimationFrame(tick);const vid=($('page-video').classList.contains('active')&&$('video-feed').videoWidth)?$('video-feed'):$('camera-feed'),canvas=$('video-canvas');if(!stream||!vid.videoWidth)return;
    const res=$('video-quality').value==='2160'?2160:1080;
    const portrait=vid.videoHeight>vid.videoWidth;
    // Frame pixel size is adjusted only when needed; cap canvas dimensions to 4K UHD.
    const targetW=portrait?res:Math.min(3840,Math.round(res*vid.videoWidth/vid.videoHeight));
    const targetH=portrait?Math.min(3840,Math.round(res*vid.videoHeight/vid.videoWidth)):res;
    if(canvas.width!==targetW||canvas.height!==targetH){canvas.width=targetW;canvas.height=targetH;}
    renderFrame(canvas.getContext('2d',{alpha:false}),vid,targetW,targetH,selectedFilter(),Number($('video-intensity').value));
    renderFrameCount++;
  };frameLoop=requestAnimationFrame(tick)
}
$('video-preset').onchange=()=>toast('Filter '+$('video-preset').selectedOptions[0].text+' aktif di preview.');
$('video-intensity').oninput=()=>status('intensity-number',$('video-intensity').value+'%');
$('video-fps').onchange=()=>{if(stream&&recorder?.state!=='recording')void startCamera(activeAudio).catch(e=>toast(e.message,true));};
async function encodeBase64(blob){
  const raw=new Uint8Array(await blob.arrayBuffer());
  let bytes='';for(let i=0;i<raw.length;i+=32768)bytes+=String.fromCharCode(...raw.subarray(i,i+32768));
  return btoa(bytes);
}
function decodeBase64Photo(encoded,mime='image/jpeg'){
  const binary=atob(encoded),chunk=32768,parts=[];
  for(let i=0;i<binary.length;i+=chunk){const s=binary.slice(i,i+chunk);const a=new Uint8Array(s.length);for(let j=0;j<s.length;j++)a[j]=s.charCodeAt(j);parts.push(a);}
  return new Blob(parts,{type:mime});
}
async function processStill(blob,mode,step){
  status(step,'Mengoreksi warna dan pencahayaan foto sumber…');
  const corrected=await localEnhance(blob,mode,'original','image/jpeg');
  const choice=$('photo-quality')?.value || '4k';
  if(choice==='real-esrgan'){
    if(corrected.blob.size>12*1048576)throw Error('Foto untuk Real-ESRGAN maksimal 12 MB; turunkan resolusi kamera sumber.');
    status(step,'Mengirim foto ke server BLINK untuk inferensi Real-ESRGAN x4…');
    // Server MUST execute trained RealESRGAN_x4plus and charge token only after success.
    // A missing checkpoint is a hard error; never show local interpolation as ESRGAN.
    const data=await api('/api/photo/realesrgan',{method:'POST',body:{image_base64:await encodeBase64(corrected.blob)}});
    if(data.engine!=='RealESRGAN_x4plus'||!data.image_base64||!data.model_sha256)throw Error('Server tidak memberikan bukti inferensi Real-ESRGAN asli.');
    return {blob:decodeBase64Photo(data.image_base64,data.mime),width:data.width,height:data.height,
      model:data.engine,modelHash:data.model_sha256,method:'RealESRGAN_x4plus server',remoteCharged:true,remainingTokens:data.tokens};
  }
  const resolution=choice==='original'?'original':'4k';
  return enhanceOnDevicePhoto(corrected.blob,mode,'image/jpeg',{resolution,backup:false,
    onProgress:(pct,label)=>status(step,`Memproses foto lokal: ${pct}% · ${label}`)});
}
$('snap').onclick=async()=>{
  if(isBusy)return;if(!user||user.tokens<=0){toast('Token tidak tersedia. Lihat paket Upgrade.',true);navigate('plans');return;}isBusy=true;$('snap').disabled=true;
  try{if(!stream)await startCamera();originalPhoto=await captureStill($('camera-feed'));
    $('photo-before').src=URL.createObjectURL(originalPhoto.blob);$('photo-result').hidden=false;
    const ai=await processStill(originalPhoto.blob,$('photo-mode').value,'camera-status');
    // Never present an unchanged original as an enhanced output after processing fails.
    processedPhoto=ai;$('photo-after').src=URL.createObjectURL(ai.blob);
    status('photo-detail',`BLINK Enhance ${ai.method||"CNN lokal"} • kamera ${originalPhoto.width} × ${originalPhoto.height} • hasil ${ai.width} × ${ai.height} px • ${readableBytes(ai.blob.size)}`);
    try{if(ai.remoteCharged){user=await api('/api/me')}else{user=await api('/api/tokens/consume',{method:'POST'})}updateWallet()}catch(e){toast('Hasil foto sudah jadi, namun token gagal disinkronkan: '+e.message,true)}
    status('camera-status','Pemrosesan selesai. Bandingkan hasil asli dan hasil BLINK, lalu simpan.');
  }catch(e){status('camera-status','Pemrosesan tidak berhasil: '+e.message);toast(e.message,true);processedPhoto=null;$('photo-after').removeAttribute('src')}
  finally{isBusy=false;$('snap').disabled=!stream;}
};
$('save-photo').onclick=()=>{if(!processedPhoto)return toast('Hasil foto belum tersedia.',true);downloadBlob(processedPhoto.blob,'BLINK-Photo-'+Date.now()+'.jpg')};

// Do not record the canvas at its default 300×150 dimensions before the first frame.
async function waitForFilteredFrame(){
  const initial=renderFrameCount,start=performance.now();
  while(renderFrameCount<=initial || $('video-canvas').width<640 || $('video-canvas').height<360){
    if(performance.now()-start>3000)throw Error('Pratinjau video belum siap. Coba nyalakan kamera kembali.');
    await new Promise(ok=>requestAnimationFrame(ok));
  }
}
// Video export records the ACTUAL filtered canvas frames, not only a CSS preview.
function recordCanvas(durationMs=0){
  if(!stream)throw Error('Kamera belum dinyalakan.');if(!window.MediaRecorder)throw Error('MediaRecorder tidak tersedia pada WebView ini.');
  const c=$('video-canvas');if(!c.captureStream)throw Error('Canvas captureStream tidak tersedia.');
  if(!c.width||!c.height)throw Error('Frame video belum siap. Tunggu preview muncul.');
  const fps=Number($('video-fps').value),output=c.captureStream(fps);
  for(const track of stream.getAudioTracks())output.addTrack(track);
  const pixels=c.width*c.height;
  // Higher quality requests; actual encoder bitrate and FPS are device dependent.
  let bitrate = pixels>=7000000 ? (fps>=60?42000000:28000000) : (fps>=60?14000000:9500000);
  if(pixels<1000000)bitrate=5000000;
  let created;
  try {created=createRecorder(output,{videoBitsPerSecond:bitrate});}
  catch(error){output.getVideoTracks().forEach(t=>t.stop());throw error;}
  const {recorder:rec,done}=created;
  const started=performance.now();const framesAtStart=renderFrameCount;
  const completed=done.then(blob=>({blob,mime:rec.mimeType,width:c.width,height:c.height,
    requestedFps:fps, approximateRenderFps:Math.max(0,Math.round((renderFrameCount-framesAtStart)*1000/Math.max(1,performance.now()-started))),
    requestedBitrate:created.encoderBitrate||bitrate,audioEnabled:Boolean(stream.getAudioTracks().length)}));
  completed.finally(()=>{output.getVideoTracks().forEach(t=>t.stop());}).catch(()=>{});
  if(durationMs)setTimeout(()=>{if(rec.state!=='inactive')rec.stop()},durationMs);
  return {rec,done:completed};
}
$('video-record').onclick=async()=>{try{
  if(isBusy)return;isBusy=true;
  await startCamera($('video-audio').checked);
  await waitForFilteredFrame();
  const {rec,done}=recordCanvas();recorder=rec;
  $('video-record').disabled=true;$('video-finish').disabled=false;
  status('video-status','Sedang merekam frame video dengan filter '+$('video-preset').selectedOptions[0].text+'...');
  done.then(result=>{videoOutput=result;$('video-playback').src=URL.createObjectURL(result.blob);$('video-result').hidden=false;
    status('video-detail',`${result.width} × ${result.height} • target ${result.requestedFps} FPS • renderer ≈${result.approximateRenderFps} FPS • target ${(result.requestedBitrate/1000000).toFixed(1)} Mbps • audio ${result.audioEnabled?'aktif':'nonaktif'} • ${readableBytes(result.blob.size)} • ${result.mime}`);
    status('video-status','Video diproses dengan filter sungguhan dan siap disimpan.');}).catch(e=>toast(e.message,true)).finally(()=>{isBusy=false;$('video-record').disabled=!stream;$('video-finish').disabled=true;});
}catch(e){isBusy=false;toast(e.message,true)}};
$('video-finish').onclick=()=>{if(recorder?.state==='recording')recorder.stop()};
$('save-video').onclick=()=>{if(!videoOutput)return toast('Video belum selesai.',true);const ext=videoOutput.mime.includes('mp4')?'mp4':'webm';downloadBlob(videoOutput.blob,'BLINK-Video-'+Date.now()+'.'+ext)};
$('upscale-video-server').onclick=async()=>{
  if(!videoOutput?.blob?.size)return toast('Rekam video terlebih dahulu.',true);
  if(videoOutput.blob.size>18*1048576)return toast('Video lebih dari 18 MB. Rekam durasi lebih pendek untuk ekspor 4K server.',true);
  if(isBusy)return;
  isBusy=true;$('upscale-video-server').disabled=true;
  status('video-status','Mengirim video untuk ekspor 4K server. Tidak menggunakan AI video.');
  try{
    const reply=await api('/api/video/upscale-4k',{method:'POST',body:{video_base64:await encodeBase64(videoOutput.blob)}});
    if(reply.width*reply.height!==3840*2160||reply.mime!=='video/mp4')throw Error('Server tidak mengembalikan video UHD yang terverifikasi.');
    const enhanced=decodeBase64Photo(reply.video_base64,'video/mp4');
    videoOutput={...videoOutput,blob:enhanced,mime:'video/mp4',width:reply.width,height:reply.height,serverUpscaled:true};
    $('video-playback').src=URL.createObjectURL(enhanced);
    status('video-detail',`UHD ${reply.width} × ${reply.height} • ${readableBytes(enhanced.size)} • ${reply.method} • piksel 4K hasil upscale, bukan restorasi AI`);
    status('video-status','Video 4K server selesai dan siap disimpan.');
  }catch(e){status('video-status','Ekspor 4K server gagal: '+e.message);toast(e.message,true);}
  finally{isBusy=false;$('upscale-video-server').disabled=false;}
};
$('live-capture').onclick=async()=>{
  if(isBusy)return;isBusy=true;
  try{await startCamera(true);const still=await captureStill($('camera-feed'));
    const {rec,done}=recordCanvas(3000);status('live-status','Merekam gerakan 3 detik...');
    const result=await processStill(still.blob,'sharp','live-status');const motion=await done;
    livePhoto=result;liveMotion=motion;$('live-picture').src=URL.createObjectURL(result.blob);$('live-motion').src=URL.createObjectURL(motion.blob);$('live-result').hidden=false;
    status('live-status','Live Photo selesai: foto diproses, video gerakan direkam.');
  }catch(e){status('live-status','Live Photo gagal: '+e.message);toast(e.message,true)}finally{isBusy=false;}
};
$('live-save-photo').onclick=()=>{if(livePhoto)downloadBlob(livePhoto.blob,'BLINK-Live-'+Date.now()+'.jpg')};
$('live-save-motion').onclick=()=>{if(liveMotion)downloadBlob(liveMotion.blob,'BLINK-Motion-'+Date.now()+(liveMotion.mime.includes('mp4')?'.mp4':'.webm'))};

// Catalog is separate from checkout. All pricing/benefits come from the BLINK server.
async function loadPlans(){const root=$('plans-list');root.textContent='Memuat katalog...';
  try{const plans=await api('/api/plans',{auth:false});root.replaceChildren();for(const plan of plans){const card=document.createElement('article');
    const h=document.createElement('h3');h.textContent=plan.name;const price=document.createElement('div');price.className='price';price.textContent=plan.enabled?new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(plan.price):'Belum tersedia';
    const details=document.createElement('p');details.className='muted';details.textContent=plan.benefits+' • '+plan.tokens+' token • '+plan.days+' hari';const buy=document.createElement('button');buy.className='button primary';buy.textContent=plan.enabled?'Pilih '+plan.name:'Paket belum diaktifkan';buy.disabled=!plan.enabled;
    buy.onclick=()=>{chosenPlan=plan;status('selected-plan',plan.name);status('selected-price',price.textContent);navigate('payment')};card.append(h,price,details,buy);root.append(card);
  }}catch(e){root.textContent='Tidak dapat memuat katalog: '+e.message}
}
async function refreshOrders(){if(!token)return;try{const orders=await api('/api/orders/mine');const root=$('payment-history');root.replaceChildren();for(const o of orders){const d=document.createElement('div');d.textContent=`Order #${o.id} • ${o.plan_id.toUpperCase()} • ${o.status} • ${new Date(o.created*1000).toLocaleString('id-ID')}`;root.append(d)}}catch(e){status('payment-status',e.message)}}
$('submit-payment').onclick=async()=>{
  if(!chosenPlan)return toast('Pilih paket dari katalog terlebih dahulu.',true);
  const file=$('payment-proof').files[0];if(!file||file.size>6*1048576)return toast('Unggah JPG/PNG maksimal 6 MB.',true);
  if(!['image/png','image/jpeg'].includes(file.type))return toast('Bukti harus JPG atau PNG.',true);
  try{const buffer=await file.arrayBuffer(),bytes=new Uint8Array(buffer);let raw='';for(let i=0;i<bytes.length;i+=0x8000)raw+=String.fromCharCode(...bytes.subarray(i,i+0x8000));
    const result=await api('/api/orders',{method:'POST',body:{plan:chosenPlan.id,proof_base64:btoa(raw),reference:$('payment-ref').value}});
    status('payment-status',`Order #${result.id} terkirim. Menunggu keputusan admin. Tidak aktif otomatis.`);toast('Bukti pembayaran diterima untuk pemeriksaan manual.');await refreshOrders();
  }catch(e){status('payment-status',e.message);toast(e.message,true)}
};
// Refresh server-side balances and payment decisions while user APK is open.
setInterval(()=>{if(token&&$('studio').classList.contains('show')){void refreshMe().catch(()=>{});if($('page-payment').classList.contains('active'))void refreshOrders();}},4000);
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&token)void refreshMe().catch(()=>{});});
window.addEventListener('pagehide',stopCamera);

// Returning users: validate the saved session, then go straight to camera.
if(token)void enterApp();
