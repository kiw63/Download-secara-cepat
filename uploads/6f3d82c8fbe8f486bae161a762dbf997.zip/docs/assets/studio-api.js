// Offline build compatibility. The remote StudioAPI is intentionally disabled.
// BLINKOfflineAPI is the sole active account/redeem implementation.
export class StudioAPI {
  constructor(){this.base='';this.token='';this.user=null;}
  setBase(){throw new Error('APK ini tidak menggunakan backend online.');}
  async request(){throw new Error('Layanan server dinonaktifkan pada APK offline.');}
  async capabilities(){throw new Error('Tidak ada backend.');}
  async login(){throw new Error('Gunakan akun lokal BLINK.');}
  async logout(){}
  async me(){throw new Error('Gunakan akun lokal BLINK.');}
  async createJob(){throw new Error('GPU server tidak tersedia offline.');}
  async job(){throw new Error('GPU server tidak tersedia offline.');}
  async download(){throw new Error('GPU server tidak tersedia offline.');}
}
