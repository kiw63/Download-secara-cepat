/* BLINK local admin issuer. Private signing key is IMPORTED by the owner,
 * validated against the bundled public key and stored AES-GCM encrypted with
 * a PBKDF2-derived key from the owner's password. It is NEVER shipped in APK.
 */
(function(){
'use strict';
const $=id=>document.getElementById(id),U=window.BLINKOfflineUtils;
const STORAGE='blink.v5.offline.admin.v1', LOG='blink.v5.offline.admin.codes.v1';
const load=(k,def)=>{try{return JSON.parse(localStorage.getItem(k))||def;}catch{return def;}};
const save=(k,d)=>localStorage.setItem(k,JSON.stringify(d));
const message=(s,err=false)=>{const e=$('admin-message');e.textContent=s;e.className='show '+(err?'admin-error':'admin-ok');};
const now=()=>new Date().toLocaleString('id-ID');
let privateKey=null,adminEmail=null;
const enc=s=>new TextEncoder().encode(s);
const pbkdf=async(pass,salt)=>{
 const m=await crypto.subtle.importKey('raw',enc(pass),'PBKDF2',false,['deriveKey']);
 return crypto.subtle.deriveKey({name:'PBKDF2',salt:U.decode(salt),iterations:250000,hash:'SHA-256'},m,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);
};
async function validateSigner(base64){
 const pk=await crypto.subtle.importKey('pkcs8',U.decode(base64),{name:'ECDSA',namedCurve:'P-256'},true,['sign']);
 const nonce=U.encode(crypto.getRandomValues(new Uint8Array(16)));
 const input=enc('BLINK-V5|PREMIUM30|20|'+nonce);
 const sig=U.encode(await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},pk,input));
 await U.verifyVoucher('BL5.'+nonce+'.'+sig); // ensures private key matches embedded public key
 return pk;
}
async function setup(){
 const email=$('setup-email').value.trim().toLowerCase(),pass=$('setup-password').value,
       confirm=$('setup-confirm').value,keyText=$('setup-private-key').value.trim().replace(/\s/g,'');
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw Error('Email admin tidak valid');
 if(pass.length<12||pass!==confirm)throw Error('Password admin harus minimal 12 karakter dan sama dengan konfirmasi.');
 if(!keyText)throw Error('Impor PRIVATE_KEY_BASE64 dari file rahasia developer, bukan public key.');
 const valid=await validateSigner(keyText);
 const salt=U.encode(crypto.getRandomValues(new Uint8Array(16))),iv=U.encode(crypto.getRandomValues(new Uint8Array(12)));
 const cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv:U.decode(iv)},await pbkdf(pass,salt),U.decode(keyText));
 save(STORAGE,{email,salt,iv,cipher:U.encode(cipher)});privateKey=valid;adminEmail=email;
 $('setup-private-key').value='';$('setup-password').value='';$('setup-confirm').value='';
 displaySession();message('Admin lokal disiapkan; kunci penandatangan disimpan terenkripsi di perangkat ini.');
}
async function login(){
 const record=load(STORAGE,null);if(!record)throw Error('Admin belum dikonfigurasi di perangkat ini.');
 if($('admin-email').value.trim().toLowerCase()!==record.email)throw Error('Akses ditolak: email admin salah.');
 try{
 const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:U.decode(record.iv)},await pbkdf($('admin-password').value,record.salt),U.decode(record.cipher));
 privateKey=await validateSigner(U.encode(plain));adminEmail=record.email;
 }catch{throw Error('Akses ditolak: password admin atau kunci salah.');}
 $('admin-password').value='';displaySession();message('Akses admin lokal berhasil.');
}
function el(tag,content,cls){const x=document.createElement(tag);if(content!==undefined)x.textContent=content;if(cls)x.className=cls;return x;}
function displaySession(){
 $('admin-setup').hidden=true;$('admin-login').hidden=true;$('admin-main').hidden=false;
 $('admin-who').textContent=adminEmail;$('admin-state').textContent='Kunci pembuat kode tersimpan lokal · Telegram @Marvel_sh';refresh();
}
function refresh(){
 const items=load(LOG,[]),users=Object.values(U.read('users',{})),used=U.read('usedCodes',[]);
 $('stat-users').textContent=users.length;
 $('stat-pending').textContent=items.filter(i=>i.status==='active').length;
 $('stat-premium').textContent=users.filter(u=>u.premium_expires>Date.now()).length;
 $('stat-expired').textContent=users.filter(u=>u.redeemed_code&&u.premium_expires<=Date.now()).length;
 const codes=$('admin-codes');codes.replaceChildren();
 for(const x of [...items].reverse()){
  const card=el('article',undefined,'order-row');card.append(el('h3',x.code));
  card.append(el('p',`${x.status==='cancelled'?'DIHAPUS DARI DAFTAR ADMIN':'DITERBITKAN'} · ${x.created_at} · 30 hari / 20 token${used.includes(x.code)?' · digunakan di perangkat admin':''}`));
  const actions=el('div',undefined,'admin-row-actions');
  const copy=el('button','Salin kode','btn btn-outline');copy.onclick=async()=>{
   try{await navigator.clipboard.writeText(x.code);message('Kode disalin, kirim ke pengguna melalui Telegram.');}
   catch{const box=$('admin-code-output');box.textContent=x.code;box.focus?.();message('Salin kode dari kotak di atas.');}
  };actions.append(copy);
  if(x.status==='active'){
   const del=el('button','✕ Hapus catatan kode','btn btn-danger');del.onclick=()=>{
    if(!confirm('Kode yang sudah dikirim tetap valid di HP pengguna yang offline. Hapus dari daftar lokal admin?'))return;
    const db=load(LOG,[]),item=db.find(z=>z.code===x.code);if(item)item.status='cancelled';save(LOG,db);refresh();
    message('Catatan kode dihapus lokal. Kode yang telah dikirim TIDAK bisa dicabut dari HP lain tanpa server.');
   };actions.append(del);
  }
  card.append(actions);codes.append(card);
 }
 if(!items.length)codes.append(el('p','Belum ada kode diterbitkan pada perangkat admin ini.'));
 const usersEl=$('admin-users');usersEl.replaceChildren();
 for(const u of users){const row=el('article',undefined,'user-row');row.append(el('strong',u.name+' · '+u.email));
  row.append(el('p',`${u.premium_expires>Date.now()?'PREMIUM AKTIF':'AKUN LOKAL'} · ${u.free_tokens} token gratis · ${u.premium_tokens} token premium`));usersEl.append(row);}
 if(!users.length)usersEl.append(el('p','Tidak ada akun lokal di perangkat admin ini. Akun pada HP pengguna lain tidak dapat dilihat tanpa server.'));
}
async function createCode(){
 if(!privateKey)throw Error('Login admin dahulu');
 if(!confirm('Pastikan pembayaran manual sudah diterima melalui Telegram sebelum membuat kode.'))return;
 const nonce=U.encode(crypto.getRandomValues(new Uint8Array(16)));
 const signature=await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},privateKey,enc('BLINK-V5|PREMIUM30|20|'+nonce));
 const code='BL5.'+nonce+'.'+U.encode(signature);
 await U.verifyVoucher(code);
 const list=load(LOG,[]);list.push({code,created_at:now(),status:'active'});save(LOG,list);
 $('admin-code-output').textContent=code;refresh();message('Kode valid diterbitkan. Kirim kode secara pribadi via Telegram.');
}
$('admin-setup-submit').onclick=async()=>{try{await setup();}catch(e){message(e.message,true);}};
$('admin-signin').onclick=async()=>{try{await login();}catch(e){message(e.message,true);}};
$('admin-code-create').onclick=async()=>{try{await createCode();}catch(e){message(e.message,true);}};
$('admin-signout').onclick=()=>{privateKey=null;adminEmail=null;$('admin-main').hidden=true;$('admin-login').hidden=false;message('Keluar dari panel admin.');};
$('admin-refresh').onclick=()=>refresh();
document.querySelectorAll('[data-admin-tab]').forEach(b=>b.onclick=()=>{
 document.querySelectorAll('[data-admin-tab]').forEach(x=>x.classList.toggle('selected',x===b));
 document.querySelectorAll('[data-view]').forEach(x=>x.hidden=x.dataset.view!==b.dataset.adminTab);
});
if(!load(STORAGE,null)){$('admin-setup').hidden=false;$('admin-login').hidden=true;}
else {$('admin-login').hidden=false;$('admin-setup').hidden=true;}
})();
