# BLINK V5 — APK OFFLINE + Telegram Premium Redeem

**Khusus Android.** Berbasis sumber BLINK V5 yang sama (UI, intro/roket, Photo Lab, CNN AI-lite, kamera, Live Photo, Video Studio). Tidak memakai Firebase, Firestore, Render, server, atau GitHub Pages saat aplikasi berjalan.

## Yang disediakan

- `docs/`: seluruh antarmuka asli dan model CNN kecil disertakan di APK. AI-lite adalah CNN lokal, BUKAN Real-ESRGAN dan target 4K bukan jaminan rekonstruksi detail.
- `android/`: Android WebView native, kamera/mikrofon, picker file, ekspor berkas ke Downloads/BLINK, navigasi Telegram @Marvel_sh. Sumber HTML/JS/CSS dikemas sebagai assets/site oleh Gradle. Android manifest tidak meminta izin INTERNET; WebView memblokir koneksi jaringan.
- `docs/assets/offline-bridge.js`: akun/password lokal PBKDF2, saldo token lokal, verifikasi kode Premium bertanda tangan digital ECDSA P-256.
- `docs/admin.html`: setup admin lokal (email/password buatan developer) dan impor private key. Private key dienkripsi AES-GCM berdasarkan password admin. Admin menerbitkan kupon 30 hari/20 token.
- `.github/workflows/build-android-apk.yml`: workflow **Build BLINK V5 Offline Android APK**.
- `qa/test_offline_redeem.cjs` dan `qa/test_offline_admin.cjs`: tes Node.js dengan kunci ephemeral; tidak berisi kunci developer.

## Bagaimana admin menerbitkan kode untuk HP lain tanpa server?

Developer memiliki file rahasia **terpisah dari ZIP ini** bernama `BLINK-V5-PRIVATE-ADMIN-KEY-DO-NOT-UPLOAD.txt`. Simpan di tempat aman dan JANGAN pernah upload ke repository GitHub, media sosial, APK publik atau mengirim ke pembeli.

APK hanya memuat **kunci publik** untuk memeriksa apakah kode ditandatangani oleh developer. Developer login ke halaman Admin di HP miliknya dan mengimpor `PRIVATE_KEY_BASE64` pada setup pertama. Setelah pembayaran diperiksa manual di Telegram, admin membuat kode `BL5.<acak>.<tanda-tangan>` lalu mengirimkannya ke pembeli via chat. Pengguna menempel kode di BLINK Premium pada HP sendiri; verifikasi kode tidak memerlukan internet.

## Batasan penting (PERLU DIBACA sebelum jualan)

- Satu akun hanya sekali redeem **pada satu perangkat**. Kode yang sama hanya dapat dipakai sekali **di perangkat yang sama**. Karena tidak ada sinkronisasi antar-HP, kode yang sama bisa dipakai sekali pada HP lain.
- Admin dapat **menghapus catatan kode di HP-nya**, tapi tidak dapat mencabut kode yang sudah tersebar ke HP lain. Tidak ada mekanisme blacklist global atau pemblokiran pembeli.
- Akun, password-hash, saldo, riwayat, dan masa aktif Premium tersimpan lokal, dapat hilang ketika data aplikasi dihapus / perangkat diganti. Tidak dapat dipulihkan melalui email. Jam HP dapat dimanipulasi, dan pengguna mahir dapat mengubah APK atau data lokal.
- Telegram membutuhkan koneksi internet saat dibuka; aplikasi inti dan pemeriksaan kode tidak.
- Foto AI tetap CNN AI-lite lokal, Video Studio adalah filter non-AI. GPU Real-ESRGAN tidak disediakan pada paket 100% offline ini.
- APK belum terkompilasi dan belum diuji di HP fisik di lingkungan ini. Tes JS/kode redeem bisa dijalankan lokal dengan Node.

## Build APK di GitHub lewat HP

1. Upload **isi ZIP**, bukan ZIP mentah, ke repository GitHub kamu. Pastikan `.github/workflows/build-android-apk.yml`, `android/app/build.gradle`, `docs/index.html` dan `docs/assets/offline-public-key.js` berada di path tersebut. Jika file lama masih ada, bersihkan versi Firestore/online yang sudah tidak dipakai agar tidak membingungkan.
2. Buka repository → **Actions** → **Build BLINK V5 Offline Android APK** → **Run workflow**.
3. Jika status hijau, buka hasil build → Artifacts → `BLINK-V5-OFFLINE-APK` → unduh ZIP artifact.
4. Ekstrak artifact, lalu instal `app-debug.apk` di HP. Ini versi debug untuk uji coba, bukan rilis tersignature produksi untuk Play Store.
5. Buka APK, daftar akun lokal. Masuk **Premium → Panel Admin Lokal** pada HP developer. Impor kunci privat sekali saja, buat email/password admin sendiri. Setelah itu kamu dapat menerbitkan kode.
6. Uji dari 2 HP nyata: login, kamera, Live Photo, Foto AI, video, unduhan file, QR pembayaran manual via Telegram (di luar aplikasi), kode asli dan kode palsu. **Jangan menerima pembayaran sungguhan sebelum uji di perangkat selesai.**

## Tes sumber di lingkungan Node

```bash
node qa/test_offline_redeem.cjs
node qa/test_offline_admin.cjs
node --check docs/assets/app.js
```

> Catatan: Kunci privat yang dibuat untuk build ini adalah pasangan dari kunci publik yang tertanam di `offline-public-key.js`. Bila kunci privat hilang, kode baru tidak bisa dibuat untuk APK publik yang sama. Membuat key baru perlu rebuild APK dengan public key baru.
