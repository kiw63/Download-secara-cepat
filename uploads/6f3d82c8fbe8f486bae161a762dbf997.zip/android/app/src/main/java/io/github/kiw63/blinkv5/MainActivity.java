package io.github.kiw63.blinkv5;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.net.http.SslError;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends Activity {
    // Bundled APK assets served as a secure HTTPS origin by shouldInterceptRequest.
    // No external website, Firestore, backend, or Android INTERNET permission.
    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    private static final String TRUSTED_HOST = "appassets.androidplatform.net";
    private static final int PICK_FILE = 810, MEDIA_PERMISSION = 811;
    private WebView web;
    private ValueCallback<Uri[]> picker;
    private PermissionRequest pendingMediaPermission;
    private final Map<String, OutputStream> streams = new HashMap<>();
    private final Map<String, Uri> pendingDownloads = new HashMap<>();

    @Override public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true); // local offline accounts and token storage
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setBlockNetworkLoads(true); // Never fetch remote scripts or APIs from within APK
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSafeBrowsingEnabled(true);
        WebView.setWebContentsDebuggingEnabled(false);
        web.addJavascriptInterface(new DownloadBridge(), "BLINK_NATIVE");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u=req.getUrl();
                if ("https".equalsIgnoreCase(u.getScheme()) && TRUSTED_HOST.equalsIgnoreCase(u.getHost())
                       && u.getPath()!=null && u.getPath().startsWith("/assets/")) return false;
                if (!req.isForMainFrame()) return true; // never navigate external subframes
                return openExternal(u);
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl();
                if (!"https".equalsIgnoreCase(uri.getScheme()) || !TRUSTED_HOST.equalsIgnoreCase(uri.getHost()))
                    return blockedResource();
                String path=uri.getPath();
                if(path==null || !path.startsWith("/assets/"))return blockedResource();
                String rel=path.substring("/assets/".length());
                if(rel.isEmpty())rel="index.html";
                if(rel.contains("..")||rel.contains("\\")||rel.startsWith("/"))return blockedResource();
                try {
                    InputStream in=getAssets().open("site/"+rel);
                    return new WebResourceResponse(mimeOf(rel),"UTF-8",in);
                }catch(Exception ignored){
                    return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",
                        java.util.Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));
                }
            }
            @Override public void onReceivedSslError(WebView view,SslErrorHandler handler,SslError error) {
                handler.cancel();
            }
            @Override public void onPageFinished(WebView view,String url) {
                if (url.startsWith(HOME)) view.evaluateJavascript(BLOB_DOWNLOAD_SCRIPT,null);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                if (!TRUSTED_HOST.equalsIgnoreCase(request.getOrigin().getHost())) {
                    request.deny(); return;
                }
                runOnUiThread(() -> {
                    boolean needsCamera=false, needsAudio=false;
                    for (String res:request.getResources()) {
                        if (res.equals(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) needsCamera=true;
                        if (res.equals(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) needsAudio=true;
                    }
                    boolean missingCamera = needsCamera && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED;
                    boolean missingAudio = needsAudio && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED;
                    if (missingCamera||missingAudio) {
                        pendingMediaPermission=request;
                        java.util.ArrayList<String> missing=new java.util.ArrayList<>();
                        if(missingCamera)missing.add(Manifest.permission.CAMERA);
                        if(missingAudio)missing.add(Manifest.permission.RECORD_AUDIO);
                        requestPermissions(missing.toArray(new String[0]),MEDIA_PERMISSION);
                    } else allowRequestedMedia(request);
                });
            }
            @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback, FileChooserParams params){
                if(picker!=null)picker.onReceiveValue(null);
                picker=callback;
                try { startActivityForResult(params.createIntent(),PICK_FILE);return true; }
                catch(ActivityNotFoundException e){picker=null;callback.onReceiveValue(null);return false;}
            }
        });
        // Blob downloads use BLINK_NATIVE, which writes to MediaStore.
        // Do not allow DownloadManager to access the network.
        web.setDownloadListener((url,ua,disposition,mime,size)->{});
        web.loadUrl(HOME);
    }

    private static WebResourceResponse blockedResource(){
        return new WebResourceResponse("text/plain","UTF-8",403,"Blocked",
          java.util.Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));
    }
    private static String mimeOf(String rel){
        String r=rel.toLowerCase(java.util.Locale.ROOT);
        if(r.endsWith(".html"))return "text/html";
        if(r.endsWith(".js"))return "text/javascript";
        if(r.endsWith(".css"))return "text/css";
        if(r.endsWith(".json"))return "application/json";
        if(r.endsWith(".png"))return "image/png";
        if(r.endsWith(".jpg")||r.endsWith(".jpeg"))return "image/jpeg";
        if(r.endsWith(".webp"))return "image/webp";
        if(r.endsWith(".svg"))return "image/svg+xml";
        if(r.endsWith(".ico"))return "image/x-icon";
        return "application/octet-stream";
    }
    private boolean openExternal(Uri uri){
        boolean telegram = ("https".equalsIgnoreCase(uri.getScheme()) && "t.me".equalsIgnoreCase(uri.getHost())
                                && uri.getPath()!=null && uri.getPath().equalsIgnoreCase("/Marvel_sh"));
        if(!telegram)return true; // deny other outside network navigation
        try {startActivity(new Intent(Intent.ACTION_VIEW,uri));}
        catch(Exception e){Toast.makeText(this,"Telegram atau browser tidak tersedia.",Toast.LENGTH_SHORT).show();}
        return true;
    }
    private void allowRequestedMedia(PermissionRequest req){
        java.util.ArrayList<String> safe=new java.util.ArrayList<>();
        for(String res:req.getResources()){
            if(res.equals(PermissionRequest.RESOURCE_VIDEO_CAPTURE))safe.add(res);
            if(res.equals(PermissionRequest.RESOURCE_AUDIO_CAPTURE))safe.add(res);
        }
        if(safe.isEmpty())req.deny();else req.grant(safe.toArray(new String[0]));
    }
    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results){
        super.onRequestPermissionsResult(code,permissions,results);
        if(code==MEDIA_PERMISSION&&pendingMediaPermission!=null){
            PermissionRequest req=pendingMediaPermission;pendingMediaPermission=null;
            boolean granted=true;
            for(int x:results)if(x!=PackageManager.PERMISSION_GRANTED)granted=false;
            if(granted)allowRequestedMedia(req);else req.deny();
        }
    }
    @Override protected void onActivityResult(int code,int result,Intent data){
        super.onActivityResult(code,result,data);
        if(code==PICK_FILE&&picker!=null){picker.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));picker=null;}
    }
    @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){
        if(picker!=null){picker.onReceiveValue(null);picker=null;}
        for(OutputStream out:streams.values())try{out.close();}catch(Exception ignored){}
        streams.clear();pendingDownloads.clear();
        if(web!=null)web.destroy();super.onDestroy();
    }

    // Blob URLs from Canvas and MediaRecorder cannot be downloaded by Android DownloadManager.
    // The native bridge streams chunks straight to MediaStore/Downloads without writing to app secrets.
    private class DownloadBridge {
        @JavascriptInterface public String beginDownload(String filename,String mime){
            String name=filename.replaceAll("[^a-zA-Z0-9._ -]","_");
            if(name.isEmpty())name="BLINK-result.bin";
            if(name.length()>100)name=name.substring(name.length()-100);
            String id=UUID.randomUUID().toString();
            try{
                ContentValues cv=new ContentValues();cv.put(MediaStore.Downloads.DISPLAY_NAME,name);
                cv.put(MediaStore.Downloads.MIME_TYPE,mime==null?"application/octet-stream":mime);
                cv.put(MediaStore.Downloads.IS_PENDING,1);
                cv.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/BLINK/");
                Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv);
                if(uri==null)throw new Exception("Downloads tidak tersedia");
                OutputStream out=getContentResolver().openOutputStream(uri);
                if(out==null)throw new Exception("Tidak bisa menyimpan file");
                synchronized(streams){streams.put(id,out);pendingDownloads.put(id,uri);}
                return id;
            }catch(Exception e){return "ERROR:"+e.getMessage();}
        }
        @JavascriptInterface public void appendChunk(String id,String data){
            synchronized(streams){
                try{
                    OutputStream out=streams.get(id);
                    if(out==null)throw new Exception("Sesi unduhan tidak ditemukan");
                    out.write(Base64.getDecoder().decode(data));
                }catch(Exception e){android.util.Log.e("BLINK","Download chunk failed",e);}
            }
        }
        @JavascriptInterface public void finishDownload(String id){
            Uri uri;
            synchronized(streams){
                try{OutputStream out=streams.remove(id);if(out!=null)out.close();}
                catch(Exception e){android.util.Log.e("BLINK","Download close failed",e);}
                uri=pendingDownloads.remove(id);
            }
            if(uri!=null){ContentValues cv=new ContentValues();cv.put(MediaStore.Downloads.IS_PENDING,0);
                getContentResolver().update(uri,cv,null,null);
                runOnUiThread(()->Toast.makeText(MainActivity.this,"Hasil tersimpan di Downloads/BLINK",Toast.LENGTH_LONG).show());}
        }
    }
    private static final String BLOB_DOWNLOAD_SCRIPT = """
        (()=>{
          if(window.__blinkNativeDownloadInstalled)return;
          window.__blinkNativeDownloadInstalled=true;
          document.addEventListener('click',async e=>{
            const a=e.target.closest('a[download]');
            if(!a || !a.href.startsWith('blob:'))return;
            e.preventDefault();
            try{
              const response=await fetch(a.href),blob=await response.blob();
              const id=window.BLINK_NATIVE.beginDownload(a.download||'BLINK-result',blob.type||'application/octet-stream');
              if(id.startsWith('ERROR:'))throw Error(id);
              const reader=blob.stream().getReader();
              for(;;){const item=await reader.read();if(item.done)break;
                for(let k=0;k<item.value.length;k+=16384){
                  const part=item.value.slice(k,k+16384);
                  let raw='';for(let i=0;i<part.length;i++)raw+=String.fromCharCode(part[i]);
                  window.BLINK_NATIVE.appendChunk(id,btoa(raw));
                }
              }
              window.BLINK_NATIVE.finishDownload(id);
            }catch(err){alert('Gagal mengunduh hasil: '+err.message);}
          },true);
        })();
        """;
}
