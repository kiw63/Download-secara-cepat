'use strict';
const {readFileSync}=require('fs'),{resolve}=require('path'),vm=require('vm'),assert=require('assert/strict');
const {webcrypto}=require('crypto');
const root=resolve(__dirname,'../docs/assets');
class Store{constructor(){this.items=new Map()}getItem(k){return this.items.get(k)??null}setItem(k,v){this.items.set(k,String(v))}removeItem(k){this.items.delete(k)}}
class FakeElement{
  constructor(id){this.id=id;this.value='';this.textContent='';this.hidden=false;this.children=[];this.className='';this.dataset={};this.classList={toggle(){}}}
  append(...kids){this.children.push(...kids)}replaceChildren(...kids){this.children=kids}focus(){}
}
function b64(ar){return Buffer.from(ar).toString('base64')}
(async()=>{
 const kp=await webcrypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
 const pub=b64(await webcrypto.subtle.exportKey('spki',kp.publicKey));
 const prv=b64(await webcrypto.subtle.exportKey('pkcs8',kp.privateKey));
 const store=new Store(),elements=new Map();
 const find=id=>{if(!elements.has(id))elements.set(id,new FakeElement(id));return elements.get(id)};
 const document={getElementById:find,querySelectorAll:()=>[],createElement:tag=>new FakeElement(tag)};
 const win={BLINK_OFFLINE_SIGNING_PUBLIC_KEY:pub};
 const ctx=vm.createContext({window:win,document,localStorage:store,crypto:webcrypto,TextEncoder,TextDecoder,
  btoa:s=>Buffer.from(s,'binary').toString('base64'),atob:s=>Buffer.from(s,'base64').toString('binary'),Date,
  console,confirm:()=>true});
 vm.runInContext(readFileSync(resolve(root,'offline-bridge.js'),'utf8'),ctx);
 vm.runInContext(readFileSync(resolve(root,'offline-admin.js'),'utf8'),ctx);
 assert.equal(find('admin-setup').hidden,false);
 find('setup-email').value='owner@example.com';find('setup-password').value='MyPrivateAdminPassword_2026';
 find('setup-confirm').value='MyPrivateAdminPassword_2026';find('setup-private-key').value=prv;
 await find('admin-setup-submit').onclick();
 assert.equal(find('admin-main').hidden,false);
 assert.equal(store.getItem('blink.v5.offline.admin.v1').includes(prv),false);
 await find('admin-code-create').onclick();
 const code=find('admin-code-output').textContent;
 assert.match(code,/^BL5\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{86}$/);
 const APP=win.BLINKOfflineAPI,app=new APP();
 await app.register({name:'Someone',email:'a@example.com',password:'BigUserPassword12345'});
 await app.login('a@example.com','BigUserPassword12345');
 await app.redeemCode(code);
 assert.equal((await app.me()).premium_active,true);
 find('admin-signout').onclick();
 find('admin-email').value='owner@example.com';find('admin-password').value='wrong-password';
 await find('admin-signin').onclick();
 assert.equal(find('admin-main').hidden,true);
 find('admin-password').value='MyPrivateAdminPassword_2026';
 await find('admin-signin').onclick();assert.equal(find('admin-main').hidden,false);
 console.log('PASS: private-key validation, AES-GCM storage encryption, admin first-use setup, signed coupon issuance, offline redemption, invalid admin login rejection, valid admin re-login.');
})().catch(e=>{console.error(e);process.exitCode=1});
