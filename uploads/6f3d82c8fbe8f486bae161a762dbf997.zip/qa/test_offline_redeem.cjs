'use strict';
// Local-only functional test. Generates an ephemeral signer; NEVER includes developer secret.
const {readFileSync}=require('fs'),{resolve}=require('path');
const {webcrypto}=require('crypto'),vm=require('vm'),assert=require('assert/strict');
const site=resolve(__dirname,'../docs/assets');
const source=readFileSync(resolve(site,'offline-bridge.js'),'utf8');
class MemStore{
  constructor(){this.map=new Map();}
  getItem(k){return this.map.get(k)??null;}
  setItem(k,v){this.map.set(k,String(v));}
  removeItem(k){this.map.delete(k);}
}
async function start(store,pub){
  const win={BLINK_OFFLINE_SIGNING_PUBLIC_KEY:pub};
  const ctx=vm.createContext({window:win,localStorage:store,crypto:webcrypto,TextEncoder,TextDecoder,
    atob:s=>Buffer.from(s,'base64').toString('binary'),btoa:s=>Buffer.from(s,'binary').toString('base64'),Date,console});
  vm.runInContext(source,ctx);return win;
}
async function makeCoupon(kp,nonce){
  const body='BLINK-V5|PREMIUM30|20|'+nonce;
  const sig=await webcrypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},kp.privateKey,new TextEncoder().encode(body));
  return 'BL5.'+nonce+'.'+Buffer.from(sig).toString('base64url');
}
(async()=>{
  const kp=await webcrypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
  const pub=Buffer.from(await webcrypto.subtle.exportKey('spki',kp.publicKey)).toString('base64');
  const store=new MemStore(),win=await start(store,pub),API=win.BLINKOfflineAPI;
  const user=new API();
  await assert.rejects(user.register({name:'Hi',email:'a@example.com',password:'short'}),/12 karakter/);
  await user.register({name:'Pengguna Satu',email:'a@example.com',password:'ReallyLongPass1234'});
  await assert.rejects(user.login('a@example.com','wrong'),/salah/);
  await user.login('a@example.com','ReallyLongPass1234');
  assert.equal((await user.me()).free_tokens,3);
  await user.consumeToken(1);assert.equal((await user.me()).free_tokens,2);
  const nonce=Buffer.from(webcrypto.getRandomValues(new Uint8Array(16))).toString('base64url');
  const coupon=await makeCoupon(kp,nonce);
  const invalid=coupon.slice(0,-1)+(coupon.endsWith('A')?'B':'A');
  await assert.rejects(user.redeemCode(invalid),/tidak valid/);
  await user.redeemCode(coupon);
  assert.equal((await user.me()).premium_tokens,20);
  assert.equal((await user.me()).premium_active,true);
  await assert.rejects(user.redeemCode(coupon),/sudah pernah/);
  await user.logout();
  await user.register({name:'Pengguna Dua',email:'b@example.com',password:'AnotherLongPass0987'});
  await user.login('b@example.com','AnotherLongPass0987');
  await assert.rejects(user.redeemCode(coupon),/sudah digunakan/);
  // Browser restart restores local session and persisted account state.
  const reboot=await start(store,pub);const resumed=new reboot.BLINKOfflineAPI();
  assert.equal((await resumed.me()).email,'b@example.com');
  const otherStore=new MemStore(),otherWin=await start(otherStore,pub);
  const other=new otherWin.BLINKOfflineAPI();
  await other.register({name:'Beda Perangkat',email:'c@example.com',password:'ThirdLongPass123456'});
  await other.login('c@example.com','ThirdLongPass123456');
  await other.redeemCode(coupon); // Explicit accepted limitation: no global synchronization.
  assert.equal((await other.me()).premium_active,true);
  console.log('PASS: offline registration, login, password rejection, persisted session, token spend, signed redeem, forged-code rejection, local 1x use, cross-device limitation.');
})().catch(e=>{console.error(e);process.exitCode=1;});
