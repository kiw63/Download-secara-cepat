# PETUNJUK CEPAT LEWAT HP ANDROID

## A. Bangun APK dari GitHub
1. Ekstrak `BLINK-V5-APK-OFFLINE-FULL-REPO.zip`.
2. Unggah isi folder ter-ekstrak ke repository `BLINK-V5` (bukan mengunggah ZIP saja).
3. Buka **Actions** -> **Build BLINK V5 Offline Android APK** -> **Run workflow**.
4. Jika sukses (centang hijau), masuk run -> **Artifacts** -> unduh `BLINK-V5-OFFLINE-APK` -> ekstrak -> instal `app-debug.apk`.

## B. Setup Developer / Admin
1. Simpan `BLINK-V5-PRIVATE-ADMIN-KEY-DO-NOT-UPLOAD.txt` di tempat aman, **JANGAN UPLOAD KE GITHUB**. Kunci rahasia ini diberikan terpisah dari ZIP publik.
2. Buka BLINK di HP milik developer -> tab **Premium** -> **Panel Admin Lokal**.
3. Pada pertama kali, isi email admin, password baru minimal 12 karakter, dan konfirmasi password.
4. Buka file rahasia, cari `PRIVATE_KEY_BASE64:` kemudian **salin hanya teks panjang di baris sesudahnya**, bukan tulisan label dan bukan `PUBLIC_KEY_BASE64`.
5. Paste ke kolom kunci privat -> **Aktifkan Admin Lokal**. Kunci privat dienkripsi dan disimpan hanya pada HP developer.
6. Untuk masuk kembali, isi email dan password admin buatanmu. Tidak ada akun admin/password baku dalam APK.
7. Pastikan pembayaran masuk lewat Telegram `@Marvel_sh`. Di panel admin -> **Buat Kode Unik** -> salin kode panjang berawalan `BL5.` lalu kirim ke pembeli melalui Telegram.

## C. Pengguna Redeem
1. Instal APK yang sama, buka **AI Lokal Studio**, pilih **Buat akun** dan login di HP itu.
2. Tekan **Premium** -> tempel **seluruh kode** dari Telegram persis apa adanya -> **Redeem Kode Premium**.
3. Jika tanda tangan valid, Premium 30 hari dan 20 token aktif pada akun di HP tersebut.
4. Redeem akun/kode kedua kali pada HP yang sama ditolak. Di HP lain kode mungkin masih bisa dipakai; tanpa server aturan global tidak ada.

## D. Hal penting
- Inti aplikasi dan kode redeem bekerja tanpa internet, **Telegram hanya saat HP online**.
- Jangan hapus data aplikasi; akun, token, dan riwayat Premium akan hilang.
- Admin yang menghapus kode dari daftarnya hanya menghapus catatan lokal, tidak menonaktifkan kode di perangkat lain.
- Build Github/Android fisik harus benar-benar berhasil sebelum kamu membagikan APK kepada pembeli.
