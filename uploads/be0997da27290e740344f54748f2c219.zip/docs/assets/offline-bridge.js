/* BLINK V5 OFFLINE: local identity, token accounting and ECDSA P-256 Premium vouchers.
 * No network, Firebase, passwords or private signing keys are embedded in the APK.
 * Local-only records are NOT tamper-resistant and are lost when app data is cleared.
 */
(function () {
  'use strict';
  const PREFIX='blink.v5.offline.', DAY=86400000;
  const encode=b=>btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
  const decode=s=>Uint8Array.from(atob(String(s).replace(/-/g,'+').replace(/_/g,'/')+'='.repeat((4-s.length%4)%4)),x=>x.charCodeAt(0));
  const text=s=>new TextEncoder().encode(s);
  const key=s=>PREFIX+s;
  const read=(name,fallback)=>{try {return JSON.parse(localStorage.getItem(key(name))||'null')??fallback;}catch{return fallback;}};
  const write=(name,value)=>localStorage.setItem(key(name),JSON.stringify(value));
  const emailOf=s=>String(s||'').trim().toLowerCase();
  const id=()=>encode(crypto.getRandomValues(new Uint8Array(16)));
  const freshTokens=u=>{const now=Date.now();if(now-u.last_daily_refresh>=DAY){u.free_tokens=3;u.last_daily_refresh=now;}return u;};
  const view=u=>({id:u.id,name:u.name,email:u.email,role:'user',free_tokens:u.free_tokens,
    premium_tokens:u.premium_tokens,premium_active:Number(u.premium_expires)>Date.now(),
    premium_expires:u.premium_expires?new Date(u.premium_expires).toISOString():null,
    redeemed_code:u.redeemed_code||null});
  async function hashPassword(password,salt){
    const k=await crypto.subtle.importKey('raw',text(password),'PBKDF2',false,['deriveBits']);
    return encode(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:decode(salt),iterations:200000},k,256));
  }
  async function verifyVoucher(code){
    const normalized=String(code||'').trim();
    const match=/^BL5\.([A-Za-z0-9_-]{22})\.([A-Za-z0-9_-]{86})$/.exec(normalized);
    if(!match)throw Error('Format kode salah. Salin seluruh kode BL5 dari developer melalui Telegram.');
    const publicKey=await crypto.subtle.importKey('spki',decode(window.BLINK_OFFLINE_SIGNING_PUBLIC_KEY),{name:'ECDSA',namedCurve:'P-256'},false,['verify']);
    const authentic=await crypto.subtle.verify({name:'ECDSA',hash:'SHA-256'},publicKey,decode(match[2]),text('BLINK-V5|PREMIUM30|20|'+match[1]));
    if(!authentic)throw Error('Kode tidak valid: tanda tangan digital tidak cocok.');
    return normalized;
  }
  class OfflineStudioAPI {
    constructor(){this.base='offline://apk';this.token='';this.user=null;this.mode='offline';this.init();}
    setBase(){return this.base;}
    async init(){
      const token=read('session',null);
      if(token){const all=read('users',{});const current=Object.values(all).find(u=>u.id===token);
        if(current){this.token=current.id;this.user=view(freshTokens(current));write('users',all);}}
      return this;
    }
    async capabilities(){return {api_version:2,services:{ai_gpu_verified:false,ai_models_installed:false,offline_local:true},limits:{photo_mb:32,video_mb:160,video_seconds:65}};}
    async register({name,email,password}){
      name=String(name||'').trim();email=emailOf(email);
      if(name.length<2||name.length>120)throw Error('Nama harus 2–120 karakter.');
      if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw Error('Format email tidak valid.');
      if(String(password||'').length<12)throw Error('Password minimal 12 karakter.');
      const users=read('users',{});
      if(users[email])throw Error('Email sudah terdaftar di perangkat ini.');
      const salt=id(),now=Date.now();
      users[email]={id:id(),name,email,password_salt:salt,password_hash:await hashPassword(password,salt),
        free_tokens:3,premium_tokens:0,premium_expires:null,redeemed_code:null,last_daily_refresh:now,created_at:now};
      write('users',users);return {verification_email_sent:false,local_registration:true};
    }
    async login(email,password){
      const emailKey=emailOf(email),users=read('users',{}),u=users[emailKey];
      if(!u||!u.password_hash||await hashPassword(password,u.password_salt)!==u.password_hash)
        throw Error('Email atau password salah pada perangkat ini.');
      this.token=u.id;write('session',this.token);this.user=view(freshTokens(u));write('users',users);
      return {access_token:'local-device-session',user:this.user};
    }
    async logout(){this.token='';this.user=null;localStorage.removeItem(key('session'));}
    async me(){
      if(!this.token)throw Error('Masuk dahulu ke akun BLINK lokal.');
      const users=read('users',{}),u=Object.values(users).find(x=>x.id===this.token);
      if(!u){await this.logout();throw Error('Akun lokal tidak tersedia.');}
      freshTokens(u);write('users',users);this.user=view(u);return this.user;
    }
    async consumeToken(cost=1){
      if(cost!==1)throw Error('Biaya token tidak valid.');
      await this.me();const users=read('users',{}),u=users[this.user.email];
      if(u.free_tokens>0)u.free_tokens--;
      else if(Number(u.premium_expires)>Date.now()&&u.premium_tokens>0)u.premium_tokens--;
      else throw Error('Token tidak cukup. Tunggu 24 jam atau gunakan Premium.');
      write('users',users);return this.me();
    }
    async redeemCode(code){
      await this.me();const valid=await verifyVoucher(code);
      const users=read('users',{}),u=users[this.user.email];
      if(u.redeemed_code)throw Error('Akun ini sudah pernah redeem satu kali di perangkat ini.');
      const used=read('usedCodes',[]);
      if(used.includes(valid))throw Error('Kode ini sudah digunakan pada perangkat ini.');
      u.redeemed_code=valid;u.premium_expires=Date.now()+30*DAY;u.premium_tokens=20;
      used.push(valid);write('users',users);write('usedCodes',used);
      return this.me();
    }
    async request(path,opts={}){
      if(path==='/api/auth/register'&&opts.method==='POST')return this.register(JSON.parse(opts.body));
      if(path==='/api/auth/request-reset')throw Error('Reset via email tidak tersedia offline. Buat backup akun secara lokal; jangan hapus data aplikasi.');
      throw Error('Fitur server tidak tersedia dalam APK offline: '+path);
    }
    async createJob(){throw Error('GPU server tidak tersedia secara offline. Gunakan AI-lite lokal untuk foto.');}
    async job(){throw Error('Pekerjaan GPU tidak tersedia secara offline.');}
    async download(){throw Error('Unduhan GPU server tidak tersedia secara offline.');}
  }
  window.BLINKOfflineAPI=OfflineStudioAPI;
  window.BLINKOfflineUtils=Object.freeze({verifyVoucher,encode,decode,text,read,write,key});
})();
