THIS IS NOT A MODEL. The trained Real-ESRGAN x4plus .bin and .param files are downloaded
from official upstream releases when running GitHub Actions, then packaged in APK assets.
The APK build must fail if real weights or the native NCNN library are missing.
