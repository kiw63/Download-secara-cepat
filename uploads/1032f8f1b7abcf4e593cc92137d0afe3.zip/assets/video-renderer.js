/** BLINK original real-time video renderer. WebGL GPU effects + CPU fallback.
 * Renders into the SAME canvas that MediaRecorder.captureStream() records.
 * No licensed third-party LUTs, no fake preview-only effects.
 */
import {VIDEO_FILTERS} from './media.js';

const clamp=(v,lo,hi)=>Math.max(lo,Math.min(hi,v));
export function filterUniforms(selection='natural',intensity=75){
  const name=selection==='natural'?'natural':selection;
  const preset=name==='natural'?null:VIDEO_FILTERS[name];
  if(name!=='natural'&&!preset)throw new Error('Preset filter tidak tersedia: '+name);
  const strength=clamp(Number(intensity)||0,0,150)/100;
  const amount=name==='natural'?0:Math.min(1,strength*1.24);
  const boost=1.4*Math.max(.1,strength);
  return {name,amount,brightness:Math.pow(preset?.brightness||1,boost),
    contrast:clamp(1+((preset?.contrast||1)-1)*boost,.5,2.4),
    saturation:clamp(1+((preset?.saturate??1)-1)*boost,0,2.5),
    sepia:clamp((preset?.sepia??0)*boost,0,.85),hue:clamp((preset?.hue||0)*boost,-80,80)*Math.PI/180,
    sharpness:name==='natural'?0.60:1.02};
}

// Fallback uses actual ImageData per pixel. Deliberately independent of
// CanvasRenderingContext2D.filter, which older Android WebViews may ignore.
export function gradePixels(data, width, height, settings){
  const {amount,brightness,contrast,saturation,sepia,hue}=settings;
  if(!amount)return data;
  const a=Math.cos(hue),b=Math.sin(hue);
  for(let i=0;i<data.length;i+=4){
    let r=data[i]/255,g=data[i+1]/255,bl=data[i+2]/255;
    const originalR=r,originalG=g,originalB=bl;
    const lum=.2126*r+.7152*g+.0722*bl;
    r=lum+(r-lum)*saturation;g=lum+(g-lum)*saturation;bl=lum+(bl-lum)*saturation;
    let nr=r*(1-.607*sepia)+g*(.769*sepia)+bl*(.189*sepia);
    let ng=r*(.349*sepia)+g*(1-.314*sepia)+bl*(.168*sepia);
    let nb=r*(.272*sepia)+g*(.534*sepia)+bl*(1-.869*sepia);
    const y=.299*nr+.587*ng+.114*nb, ii=.596*nr-.274*ng-.322*nb,qq=.211*nr-.523*ng+.312*nb;
    const I=ii*a-qq*b,Q=ii*b+qq*a;
    r=(y+.956*I+.621*Q-.5)*contrast+.5;
    g=(y-.272*I-.647*Q-.5)*contrast+.5;
    bl=(y-1.106*I+1.703*Q-.5)*contrast+.5;
    data[i]=Math.round(clamp((originalR+(r*brightness-originalR)*amount)*255,0,255));
    data[i+1]=Math.round(clamp((originalG+(g*brightness-originalG)*amount)*255,0,255));
    data[i+2]=Math.round(clamp((originalB+(bl*brightness-originalB)*amount)*255,0,255));
  }
  return data;
}
const vertex=`attribute vec2 a_position;
varying vec2 v_uv;
void main(){v_uv=(a_position+1.0)*0.5;gl_Position=vec4(a_position,0.,1.);}`;
const fragment=`precision highp float;
varying vec2 v_uv;
uniform sampler2D u_texture;
uniform vec2 u_texel,u_crop,u_shift;
uniform float u_brightness,u_contrast,u_sat,u_sepia,u_hue,u_strength,u_sharp;
vec3 grade(vec3 color){
  float luma=dot(color,vec3(.2126,.7152,.0722));
  vec3 c=mix(vec3(luma),color,u_sat);
  vec3 sep=vec3(dot(c,vec3(.393,.769,.189)),dot(c,vec3(.349,.686,.168)),dot(c,vec3(.272,.534,.131)));
  c=mix(c,sep,u_sepia);
  float Y=dot(c,vec3(.299,.587,.114));
  float I=dot(c,vec3(.596,-.274,-.322));
  float Q=dot(c,vec3(.211,-.523,.312));
  float si=sin(u_hue),co=cos(u_hue);
  float p=I*co-Q*si,q=I*si+Q*co;
  c=vec3(Y+.956*p+.621*q,Y-.272*p-.647*q,Y-1.106*p+1.703*q);
  return clamp(((c-.5)*u_contrast+.5)*u_brightness,0.,1.);
}
void main(){
  vec2 uv=(v_uv-.5)*u_crop+.5+u_shift;
  vec3 orig=texture2D(u_texture,uv).rgb;
  vec3 edge=orig-(texture2D(u_texture,uv+vec2(u_texel.x,0.)).rgb+
    texture2D(u_texture,uv-vec2(u_texel.x,0.)).rgb+
    texture2D(u_texture,uv+vec2(0.,u_texel.y)).rgb+
    texture2D(u_texture,uv-vec2(0.,u_texel.y)).rgb)*.25;
  // A restrained detail enhancement, not hallucinated 4K texture.
  // Enhance structural edges, not fine grain. Limit overshoot to avoid halos.
  float edgeLuma=dot(edge,vec3(.2126,.7152,.0722));
  float confidence=smoothstep(.006,.028,abs(edgeLuma));
  float correction=clamp(edgeLuma,-.065,.065)*u_sharp*confidence;
  // Detail recovery remains active even with Natural/no color filter.
  gl_FragColor=vec4(clamp(mix(orig,grade(orig),u_strength)+vec3(correction),0.,1.),1.);
}`;
function program(gl){
  const compile=(kind,src)=>{const shader=gl.createShader(kind);gl.shaderSource(shader,src);gl.compileShader(shader);
    if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw Error('GLSL: '+gl.getShaderInfoLog(shader));return shader;};
  const p=gl.createProgram();gl.attachShader(p,compile(gl.VERTEX_SHADER,vertex));gl.attachShader(p,compile(gl.FRAGMENT_SHADER,fragment));gl.linkProgram(p);
  if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error('WebGL: '+gl.getProgramInfoLog(p));return p;
}
export function createVideoRenderer(canvas,{forceCPU=false}={}){
  let gl=null,ctx=null,setup=null,texture=null,buffer=null,uniforms=null,working=null,workingCtx=null;
  let textureWidth=0,textureHeight=0;
  if(!forceCPU)try{gl=canvas.getContext('webgl',{alpha:false,antialias:false,depth:false,stencil:false,preserveDrawingBuffer:true,powerPreference:'high-performance'});}catch{}
  if(gl){
    try{
      const p=program(gl);gl.useProgram(p);setup=p;
      const pos=gl.getAttribLocation(p,'a_position');buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);
      gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),gl.STATIC_DRAW);
      gl.enableVertexAttribArray(pos);gl.vertexAttribPointer(pos,2,gl.FLOAT,false,0,0);
      texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);
      uniforms={};for(const key of ['texture','texel','crop','shift','brightness','contrast','sat','sepia','hue','strength','sharp'])
        uniforms[key]=gl.getUniformLocation(p,'u_'+key);
      gl.uniform1i(uniforms.texture,0);
    }catch(error){
      // A WebGL canvas cannot later request 2D, so replace this canvas with
      // an identical element. The actual recorder resolves it by id.
      console.warn('BLINK: WebGL unsupported, falling back to pixel CPU:',error);
      const replacement=canvas.cloneNode(false);canvas.replaceWith(replacement);
      return createVideoRenderer(replacement,{forceCPU:true});
    }
  }else{
    ctx=canvas.getContext('2d',{alpha:false,willReadFrequently:false});
    if(!ctx)throw new Error('Tidak ada renderer video WebGL/Canvas2D pada perangkat');
    working=document.createElement('canvas');workingCtx=working.getContext('2d',{willReadFrequently:true,alpha:false});
  }
  // Some Android WebViews accelerate Canvas2D.filter; validate real pixel
  // output once and keep per-pixel processing when their filter is decorative.
  let verified2dFilter=false;
  if(!gl){
    try {
      const probe=document.createElement('canvas');probe.width=probe.height=1;
      const pc=probe.getContext('2d',{willReadFrequently:true});
      const black=document.createElement('canvas');black.width=black.height=1;
      black.getContext('2d').fillRect(0,0,1,1);
      pc.filter='invert(1)';pc.drawImage(black,0,0);
      verified2dFilter=pc.getImageData(0,0,1,1).data[0]>220;
    }catch{verified2dFilter=false;}
  }
  let frameCount=0,renderType=gl?'WebGL GPU':(verified2dFilter?'Canvas2D CPU filter':'Canvas2D CPU pixels'),softwareFallback=null;
  function useSoftware(error){
    console.warn('BLINK: GPU renderer fallback',error);
    if(!softwareFallback){
      const replacement=canvas.cloneNode(false);canvas.replaceWith(replacement);
      softwareFallback=createVideoRenderer(replacement,{forceCPU:true});
    }
    return softwareFallback;
  }
  function render(source,width,height,selection='natural',intensity=100,stabilize={x:0,y:0,scale:1}){
    if(softwareFallback)return softwareFallback.render(source,width,height,selection,intensity,stabilize);
    if(!(source.videoWidth||source.width)||!(source.videoHeight||source.height))return false;
    if(canvas.width!==width||canvas.height!==height){canvas.width=width;canvas.height=height;}
    const s=filterUniforms(selection,intensity);
    if(gl){
      try{
      if(gl.isContextLost())throw new Error('GPU kehilangan konteks');
      gl.viewport(0,0,width,height);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture);
      const sw=source.videoWidth||source.width,sh=source.videoHeight||source.height;
      if(sw!==textureWidth||sh!==textureHeight){
        gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,source);
        textureWidth=sw;textureHeight=sh;
      }else gl.texSubImage2D(gl.TEXTURE_2D,0,0,0,gl.RGBA,gl.UNSIGNED_BYTE,source);
      const sourceAspect=sw/sh,targetAspect=width/height;
      const cropX=sourceAspect>targetAspect?targetAspect/sourceAspect:1;
      const cropY=sourceAspect>targetAspect?1:sourceAspect/targetAspect;
      gl.uniform2f(uniforms.crop,cropX*(stabilize.scale||1),cropY*(stabilize.scale||1));
      gl.uniform2f(uniforms.shift,stabilize.x||0,stabilize.y||0);
      gl.uniform2f(uniforms.texel,1/sw,1/sh);
      gl.uniform1f(uniforms.brightness,s.brightness);gl.uniform1f(uniforms.contrast,s.contrast);
      gl.uniform1f(uniforms.sat,s.saturation);gl.uniform1f(uniforms.sepia,s.sepia);
      gl.uniform1f(uniforms.hue,s.hue);gl.uniform1f(uniforms.strength,s.amount);
      gl.uniform1f(uniforms.sharp,s.sharpness);
      gl.drawArrays(gl.TRIANGLE_STRIP,0,4);
      if(frameCount%30===0 && gl.getError()!==gl.NO_ERROR)throw Error('GPU gagal menerapkan filter frame video');
      gl.flush();
      }catch(error){return useSoftware(error).render(source,width,height,selection,intensity,stabilize);}
    }else{
      // Process at up to 1280 px to avoid allocating several huge buffers per frame.
      const scale=Math.min(1,1280/Math.max(width,height));
      const iw=Math.max(2,Math.round(width*scale)),ih=Math.max(2,Math.round(height*scale));
      if(working.width!==iw||working.height!==ih){working.width=iw;working.height=ih;}
      const sw=source.videoWidth||source.width,sh=source.videoHeight||source.height;
      const imageAspect=sw/sh,outputAspect=iw/ih;
      let sx=0,sy=0,cw=sw,ch=sh;
      if(imageAspect>outputAspect){cw=ch*outputAspect;sx=(sw-cw)/2;}
      else{ch=cw/outputAspect;sy=(sh-ch)/2;}
      const factor=stabilize.scale||1;
      sx+=(cw-cw*factor)/2+(stabilize.x||0)*sw;
      sy+=(ch-ch*factor)/2+(stabilize.y||0)*sh;cw*=factor;ch*=factor;
      sx=Math.max(0,Math.min(sw-cw,sx));sy=Math.max(0,Math.min(sh-ch,sy));
      workingCtx.filter='none';
      workingCtx.drawImage(source,sx,sy,cw,ch,0,0,iw,ih);
      if(s.amount && verified2dFilter){
        workingCtx.globalAlpha=s.amount;
        workingCtx.filter=`brightness(${s.brightness}) contrast(${s.contrast}) saturate(${s.saturation}) sepia(${s.sepia}) hue-rotate(${s.hue*180/Math.PI}deg)`;
        workingCtx.drawImage(source,sx,sy,cw,ch,0,0,iw,ih);
        workingCtx.filter='none';workingCtx.globalAlpha=1;
      }else if(s.amount){
        const pixels=workingCtx.getImageData(0,0,iw,ih);
        gradePixels(pixels.data,iw,ih,s);workingCtx.putImageData(pixels,0,0);
      }
      ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';ctx.drawImage(working,0,0,width,height);
    }
    frameCount++;return true;
  }
  return {render,stats:()=>softwareFallback?softwareFallback.stats():({frames:frameCount,renderType}),destroy(){
    if(softwareFallback)softwareFallback.destroy();
    if(gl){gl.deleteTexture(texture);gl.deleteBuffer(buffer);gl.deleteProgram(setup);}else if(working){working.width=working.height=0;}
  }};
}
