/** Paket resmi BLINK sesuai harga developer. Manfaat dapat disesuaikan oleh admin backend. */
export const BLINK_PLANS = Object.freeze([
  {id:'free',name:'BLINK Free',price:0,tokens:3,days:0,rank:0,featured:false,subtitle:'Coba kamera dan filter dasar',features:['3 token foto per hari','6 filter foto & 8 filter video','Pratinjau kamera dan foto dasar','Ekspor foto resolusi asli','Video hingga 720p bila encoder mendukung']},
  {id:'plus',name:'BLINK Plus',price:20000,tokens:20,days:30,rank:1,featured:false,subtitle:'Untuk foto dan konten sehari-hari',features:['20 token premium / 30 hari','11 filter foto & 20 filter video','Peningkatan foto HD+ lokal','Video Full HD hingga 1080p','Live Photo dan pengaturan filter']},
  {id:'pro',name:'BLINK Pro',price:25000,tokens:50,days:30,rank:2,featured:true,subtitle:'Kreator yang ingin detail maksimal',features:['50 token premium / 30 hari','21 filter foto & 36 filter video','Foto 4K, peningkatan detail lokal','Video 4K jika encoder memungkinkan','Stabilisasi digital & pengaturan FPS']},
  {id:'promax',name:'BLINK Pro Max',price:35000,tokens:100,days:30,rank:3,featured:false,subtitle:'Semua kendali visual BLINK',features:['100 token premium / 30 hari','Semua 21 filter foto & 44 filter video','Mode foto/video resolusi tertinggi','4K video & opsi server AI jika tersedia','8K belum tersedia; hanya aktif setelah mesin 8K teruji']}
]);
export const PLAN_LEVEL = Object.freeze({free:0,plus:1,pro:2,promax:3,max:3});
export function accessLevel(user){return user?.premium_active === false && user?.tier !== 'free' ? 0 : (PLAN_LEVEL[user?.tier]??0);}
export const money = v => new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(v);
