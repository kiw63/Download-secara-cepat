import {newVideoCheckpointId,stageVideoChunk,recoverVideoChunks,cleanVideoChunks} from './smart-backup.js';
import {enhancePhotoPatch} from './photo-detail.js';
/* BLINK local media engine. Pixel processing and color grading are NOT AI. */
export function videoMime() {
  if (!window.MediaRecorder) return '';
  return ['video/mp4;codecs=h264,aac','video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm']
    .find(t => MediaRecorder.isTypeSupported(t)) || '';
}
export function downloadBlob(blob, filename) {
  if (!blob || !blob.size) throw new Error('Tidak ada berkas untuk diunduh');
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');a.href=url;a.download=filename;a.rel='noopener';
  document.body.append(a);a.click();a.remove();setTimeout(() => URL.revokeObjectURL(url), 60000);
}
export function readableBytes(n) {return n>1024*1024?`${(n/1048576).toFixed(1)} MB`:`${Math.round(n/1024)} KB`;}
export function canvasBlob(canvas, mime='image/jpeg', quality=.95) {
  return new Promise((resolve,reject)=>canvas.toBlob(b=>b&&b.size?resolve(b):reject(new Error('Gagal membuat file gambar')),mime,quality));
}
export function cropSize(w,h,aspect='source') {
  if (!w||!h) throw new Error('Resolusi kamera belum tersedia');
  const ratio = aspect==='source'?w/h:(()=>{const [a,b]=aspect.split(':').map(Number);return a/b;})();
  let cw=w,ch=h;if(w/h>ratio)cw=Math.round(h*ratio);else ch=Math.round(w/ratio);
  return {sx:Math.round((w-cw)/2),sy:Math.round((h-ch)/2),sw:cw,sh:ch};
}
/* Prefer full-resolution still capture from the camera track. Video preview frames
 * often have far fewer pixels than a camera's still-photo sensor. ImageCapture is
 * feature-detected because Android WebView implementations vary. */
export async function captureStill(video, aspect='source') {
  const track=video.srcObject?.getVideoTracks?.()[0];
  if(track && typeof window.ImageCapture==='function') {
    try {
      const photo=await new ImageCapture(track).takePhoto();
      if(photo?.size && photo.type.startsWith('image/')) {
        const im=await decodeImage(photo);
        try {
          if(aspect==='source') return {blob:photo,width:im.width,height:im.height,source:'camera-still'};
          const {sx,sy,sw,sh}=cropSize(im.width,im.height,aspect);
          const crop=document.createElement('canvas');crop.width=sw;crop.height=sh;
          crop.getContext('2d',{alpha:false}).drawImage(im,sx,sy,sw,sh,0,0,sw,sh);
          return {blob:await canvasBlob(crop,'image/jpeg',.985),width:sw,height:sh,source:'camera-still-cropped'};
        }finally{im.close?.()}
      }
    }catch(error){console.warn('BLINK: full-resolution ImageCapture unavailable; using live camera frame:',error?.message);}
  }
  if (!video.videoWidth||!video.videoHeight) throw new Error('Kamera belum siap. Pastikan preview terlihat.');
  const {sx,sy,sw,sh}=cropSize(video.videoWidth,video.videoHeight,aspect);
  const canvas=document.createElement('canvas');canvas.width=sw;canvas.height=sh;
  canvas.getContext('2d',{alpha:false}).drawImage(video,sx,sy,sw,sh,0,0,sw,sh);
  return {blob:await canvasBlob(canvas,'image/jpeg',.985),width:sw,height:sh,source:'camera-video-frame'};
}

export async function decodeImage(blob) {
  if(!blob||!blob.type.startsWith('image/'))throw new Error('Gunakan file foto JPEG, PNG, atau WebP');
  if(blob.size>32*1048576)throw new Error('Ukuran foto maksimal 32 MB untuk pemrosesan lokal');
  if(window.createImageBitmap)return await createImageBitmap(blob,{imageOrientation:'from-image'});
  const uri=URL.createObjectURL(blob);try {return await new Promise((ok,fail)=>{const im=new Image();im.onload=()=>ok(im);im.onerror=()=>fail(new Error('Gambar tidak terbaca'));im.src=uri;});}finally{URL.revokeObjectURL(uri);}
}
export const PHOTO_PARAMS={
  enhance:{gain:1.085,contrast:1.105,sat:1.045,gamma:.97,sharp:.93,denoise:.51,look:'enhance'},
  miles17:{gain:1.04,contrast:1.14,sat:.91,gamma:1.005,sharp:.64,denoise:.22,look:'miles17'},
  alam:{gain:1.045,contrast:1.12,sat:1.23,gamma:.99,sharp:.43,denoise:.18,look:'alam'},
  bunga:{gain:1.10,contrast:.965,sat:1.02,gamma:.96,sharp:.13,denoise:.36,look:'bunga'},
  senja:{gain:1.03,contrast:1.115,sat:1.12,gamma:.995,sharp:.29,denoise:.19,look:'senja'},
  crystal:{gain:1.072,contrast:1.18,sat:1.075,gamma:.975,sharp:1.1,denoise:.28,look:'crystal'},
  hd4k:{gain:1.052,contrast:1.16,sat:1.065,gamma:.98,sharp:1.23,denoise:.41,look:'hd4k'},
  cinematic:{gain:.995,contrast:1.20,sat:.88,gamma:1.02,sharp:.40,denoise:.21,look:'cinematic'},
  putih:{gain:1.10,contrast:1.08,sat:.91,gamma:.94,sharp:.35,denoise:.28,look:'putih'},
  vividplus:{gain:1.05,contrast:1.13,sat:1.31,gamma:.99,sharp:.34,denoise:.19,look:'vividplus'},
  creamy:{gain:1.065,contrast:.945,sat:.955,gamma:.98,sharp:.17,denoise:.33,look:'creamy'},
  clean:{gain:1.025,contrast:1.055,sat:1.04,gamma:1,sharp:.23,denoise:.33},
  sharp:{gain:1.035,contrast:1.14,sat:1.08,gamma:1,sharp:.94,denoise:.14},
  ultra:{gain:1.04,contrast:1.145,sat:1.10,gamma:.99,sharp:1.20,denoise:.31},
  portrait:{gain:1.025,contrast:1.025,sat:1.00,gamma:1.01,sharp:.15,denoise:.25},
  night:{gain:1.21,contrast:1.08,sat:1.06,gamma:.89,sharp:.20,denoise:.60},
  vivid:{gain:1.035,contrast:1.1,sat:1.22,gamma:.99,sharp:.35},
  cinema:{gain:.98,contrast:1.14,sat:.90,gamma:1.00,sharp:.34},
  analog:{gain:1.06,contrast:1.07,sat:0.8,gamma:1.0,sharp:0.3,denoise:.20},
  retro:{gain:1.065,contrast:1.12,sat:0.83,gamma:1.0,sharp:0.28,denoise:.20},
  blackwhite:{gain:1.02,contrast:1.14,sat:0.0,gamma:1.0,sharp:0.29,denoise:.20},
  pastel:{gain:1.1,contrast:0.93,sat:0.83,gamma:1.03,sharp:0.16,denoise:.20},
  golden:{gain:1.1,contrast:1.08,sat:1.13,gamma:0.98,sharp:0.32,denoise:.20},
  icy:{gain:1.02,contrast:1.13,sat:0.82,gamma:0.99,sharp:0.39,denoise:.20},
  moody:{gain:0.91,contrast:1.2,sat:0.84,gamma:1.05,sharp:0.37,denoise:.20},
  teal:{gain:1.02,contrast:1.15,sat:1.12,gamma:1.0,sharp:0.35,denoise:.20},
  travel:{gain:1.09,contrast:1.1,sat:1.15,gamma:0.99,sharp:0.29,denoise:.20},
  food:{gain:1.13,contrast:1.14,sat:1.27,gamma:0.98,sharp:0.33,denoise:.20},
  beauty:{gain:1.06,contrast:1.02,sat:1.01,gamma:1.0,sharp:0.1,denoise:.20},
  glow:{gain:1.11,contrast:0.95,sat:1.07,gamma:1.0,sharp:0.13,denoise:.20},
  nightblue:{gain:1.14,contrast:1.12,sat:1.1,gamma:0.86,sharp:0.21,denoise:.20},
  street:{gain:0.99,contrast:1.27,sat:0.89,gamma:0.98,sharp:0.49,denoise:.20},
  fresh:{gain:1.08,contrast:1.09,sat:1.21,gamma:1.0,sharp:0.28,denoise:.20}
};
export const PHOTO_TINT=Object.freeze({
  enhance:Object.freeze([1.01,1.01,1.01]),
  miles17:Object.freeze([1.025,1,1.035]),
  alam:Object.freeze([.975,1.04,1.045]),
  bunga:Object.freeze([1.045,1.018,1.025]),
  senja:Object.freeze([1.09,1.027,.925]),
  crystal:Object.freeze([.995,1.014,1.035]),
  hd4k:Object.freeze([1.012,1.012,1.012]),
  cinematic:Object.freeze([1.045,1.005,1.055]),
  putih:Object.freeze([.970,1.018,1.065]),
  vividplus:Object.freeze([1.025,1.025,1.035]),
  creamy:Object.freeze([1.07,1.03,.98]),
  clean: Object.freeze([1.012,1.006,1.0]),
  sharp: Object.freeze([1.012,1.012,1.012]),
  ultra: Object.freeze([1.025,1.02,1.025]),
  portrait: Object.freeze([1.035,1.012,0.995]),
  night: Object.freeze([1.035,1.006,1.055]),
  vivid: Object.freeze([1.04,1.01,1.025]),
  cinema: Object.freeze([1.04,1.0,1.072]),
  analog: Object.freeze([1.06,1.01,0.93]),
  retro: Object.freeze([1.09,1.02,0.88]),
  blackwhite: Object.freeze([1,1,1]),
  pastel: Object.freeze([1.04,1.005,1.05]),
  golden: Object.freeze([1.13,1.04,0.91]),
  icy: Object.freeze([0.93,1.01,1.14]),
  moody: Object.freeze([0.97,1.005,1.12]),
  teal: Object.freeze([0.92,1.045,1.15]),
  travel: Object.freeze([1.07,1.045,1]),
  food: Object.freeze([1.08,1.045,0.96]),
  beauty: Object.freeze([1.055,1.005,1]),
  glow: Object.freeze([1.085,1.015,1.06]),
  nightblue: Object.freeze([0.88,0.99,1.17]),
  street: Object.freeze([0.96,1.02,1.07]),
  fresh: Object.freeze([0.98,1.09,1.06])
});
/** Native-resolution photo correction. Tile processing keeps 12 MP+ camera details
 * instead of scaling every source down to 3500 px before exporting. */
export async function localEnhance(blob,mode='clean',resolution='original',mime='image/jpeg',intensity=100) {
  if(resolution==='2160'){
    const {enhanceOnDevicePhoto}=await import('./ondevice-ai.js');
    return enhanceOnDevicePhoto(blob,mode,mime,{resolution:'4k'});
  }
  const params=PHOTO_PARAMS[mode];if(!params)throw new Error('Preset foto tidak tersedia');
  const tint=PHOTO_TINT[mode], strength=Math.max(0,Math.min(1.5,Number(intensity)/100));
  const source=await decodeImage(blob);
  const sw=source.width,sh=source.height;
  try{
    if(sw*sh>50000000)throw new Error('Foto terlalu besar untuk pemrosesan lokal');
    // Never resample native 12MP/16MP photographs just to fit a working canvas.
    const output=document.createElement('canvas');output.width=sw;output.height=sh;
    const dst=output.getContext('2d',{alpha:false});
    if(!dst)throw new Error('Canvas tidak tersedia untuk koreksi foto');
    const patch=document.createElement('canvas'),pc=patch.getContext('2d',{willReadFrequently:true,alpha:false});
    if(!pc)throw new Error('Canvas pemrosesan foto tidak tersedia');
    const TILE=384;
    for(let ty=0;ty<sh;ty+=TILE){
      const h=Math.min(TILE,sh-ty);
      for(let tx=0;tx<sw;tx+=TILE){
        const w=Math.min(TILE,sw-tx),lx=Math.max(0,tx-2),ly=Math.max(0,ty-2),
          rx=Math.min(sw,tx+w+2),by=Math.min(sh,ty+h+2),pw=rx-lx,ph=by-ly;
        if(patch.width!==pw||patch.height!==ph){patch.width=pw;patch.height=ph;}
        pc.drawImage(source,lx,ly,pw,ph,0,0,pw,ph);
        const raw=pc.getImageData(0,0,pw,ph).data;
        const graded=enhancePhotoPatch(raw,pw,ph,{params,tint,strength,
          detail:Math.min(1.5,params.sharp||0.1)*1.55});
        const result=pc.createImageData(w,h);
        for(let y=0;y<h;y++)for(let x=0;x<w;x++){
          const j=(y*w+x)*4,i=((y+ty-ly)*pw+x+tx-lx)*4;
          result.data[j]=graded[i];result.data[j+1]=graded[i+1];
          result.data[j+2]=graded[i+2];result.data[j+3]=255;
        }
        dst.putImageData(result,tx,ty);
      }
      // Yield between tile rows to keep Android UI and keyboard responsive.
      if((ty/TILE)%2===1)await new Promise(ok=>setTimeout(ok,0));
    }
    patch.width=patch.height=0;
    const resultBlob=await canvasBlob(output,mime,mime==='image/jpeg'?.985:undefined);
    output.width=output.height=0;
    return {blob:resultBlob,width:sw,height:sh,method:'Koreksi detail resolusi kamera penuh (non-AI)',sourceWidth:sw,sourceHeight:sh};
  }finally{source.close?.();}
}
export const VIDEO_FILTERS=Object.freeze({
  cinematic: Object.freeze({brightness:0.98,contrast:1.18,saturate:0.91,sepia:0.08,hue:-4}),
  sunset: Object.freeze({brightness:1.04,contrast:1.11,saturate:1.22,sepia:0.2,hue:-7}),
  clearblue: Object.freeze({brightness:1.035,contrast:1.12,saturate:1.16,sepia:0,hue:7}),
  sicily: Object.freeze({brightness:1.07,contrast:1.12,saturate:1.12,sepia:0.16,hue:-4}),
  dramatic: Object.freeze({brightness:0.96,contrast:1.25,saturate:0.78,sepia:0.07,hue:-4}),
  vintage: Object.freeze({brightness:1.02,contrast:1.08,saturate:0.76,sepia:0.34,hue:-10}),
  retro: Object.freeze({brightness:1.05,contrast:1.11,saturate:0.86,sepia:0.27,hue:-8}),
  noir: Object.freeze({brightness:1.0,contrast:1.23,saturate:0.0,sepia:0,hue:0}),
  mono_soft: Object.freeze({brightness:1.07,contrast:1.05,saturate:0.0,sepia:0,hue:0}),
  tealorange: Object.freeze({brightness:1.0,contrast:1.23,saturate:1.18,sepia:0.09,hue:9}),
  golden: Object.freeze({brightness:1.08,contrast:1.08,saturate:1.21,sepia:0.23,hue:-13}),
  pastel: Object.freeze({brightness:1.1,contrast:0.91,saturate:0.85,sepia:0.12,hue:8}),
  mint: Object.freeze({brightness:1.06,contrast:1.04,saturate:1.08,sepia:0,hue:18}),
  rose: Object.freeze({brightness:1.07,contrast:1.05,saturate:1.16,sepia:0.05,hue:-18}),
  coffee: Object.freeze({brightness:0.99,contrast:1.15,saturate:0.75,sepia:0.31,hue:-7}),
  moody: Object.freeze({brightness:0.86,contrast:1.25,saturate:0.81,sepia:0.04,hue:0}),
  nightcity: Object.freeze({brightness:0.96,contrast:1.23,saturate:1.24,sepia:0,hue:15}),
  neon: Object.freeze({brightness:1.01,contrast:1.28,saturate:1.46,sepia:0,hue:12}),
  icy: Object.freeze({brightness:1.045,contrast:1.12,saturate:0.84,sepia:0,hue:15}),
  ocean: Object.freeze({brightness:1.01,contrast:1.14,saturate:1.22,sepia:0,hue:13}),
  forest: Object.freeze({brightness:0.99,contrast:1.15,saturate:1.12,sepia:0.07,hue:16}),
  travel: Object.freeze({brightness:1.08,contrast:1.08,saturate:1.14,sepia:0,hue:3}),
  portraitfilm: Object.freeze({brightness:1.06,contrast:1.06,saturate:0.95,sepia:0.06,hue:-5}),
  softfilm: Object.freeze({brightness:1.07,contrast:0.96,saturate:0.87,sepia:0.12,hue:-3}),
  vlogbright: Object.freeze({brightness:1.14,contrast:1.08,saturate:1.12,sepia:0,hue:0}),
  foodpop: Object.freeze({brightness:1.07,contrast:1.13,saturate:1.38,sepia:0.04,hue:-3}),
  urban: Object.freeze({brightness:0.96,contrast:1.21,saturate:0.75,sepia:0,hue:8}),
  desert: Object.freeze({brightness:1.05,contrast:1.1,saturate:1.04,sepia:0.23,hue:-9}),
  lightleak: Object.freeze({brightness:1.14,contrast:0.93,saturate:1.13,sepia:0.12,hue:-9}),
  lavender: Object.freeze({brightness:1.08,contrast:0.99,saturate:1.04,sepia:0.03,hue:19})
,
  bluehour: Object.freeze({brightness:0.95,contrast:1.19,saturate:1.21,sepia:0,hue:22}),
  amber: Object.freeze({brightness:1.06,contrast:1.14,saturate:1.18,sepia:0.21,hue:-12}),
  silver: Object.freeze({brightness:1.05,contrast:1.30,saturate:0.02,sepia:0,hue:0}),
  pearlescent: Object.freeze({brightness:1.15,contrast:0.9,saturate:0.92,sepia:0.04,hue:7}),
  emerald: Object.freeze({brightness:1.01,contrast:1.22,saturate:1.22,sepia:0,hue:23}),
  peach: Object.freeze({brightness:1.12,contrast:0.99,saturate:1.2,sepia:0.12,hue:-15}),
  cyberpunk: Object.freeze({brightness:1.01,contrast:1.34,saturate:1.55,sepia:0,hue:24}),
  tungsten: Object.freeze({brightness:0.92,contrast:1.2,saturate:0.9,sepia:0.29,hue:-17}),
  punchy: Object.freeze({brightness:1.07,contrast:1.29,saturate:1.37,sepia:0.03,hue:1}),
  mist: Object.freeze({brightness:1.12,contrast:0.86,saturate:0.84,sepia:0.04,hue:8}),
  classic: Object.freeze({brightness:1.00,contrast:1.16,saturate:0.72,sepia:0.16,hue:-6}),
  coral: Object.freeze({brightness:1.09,contrast:1.07,saturate:1.32,sepia:0.07,hue:-13}),
  deepsea: Object.freeze({brightness:0.91,contrast:1.28,saturate:1.35,sepia:0,hue:28}),
  noirhigh: Object.freeze({brightness:0.95,contrast:1.44,saturate:0.0,sepia:0,hue:0})});
export function resolveVideoFilter(selection=[],intensity=75) {
  // Legacy single-preset calls keep working, but new UI always supplies an array.
  const legacy={natural:[],clear:['clearblue'],film:['dramatic'],gold:['sunset'],night:['cinematic']};
  const raw=typeof selection==='string'?(legacy[selection]??[selection]):selection;
  if(!Array.isArray(raw))throw new Error('Pilihan filter video tidak valid');
  const chosen=[...new Set(raw)];
  if(chosen.some(p=>!Object.hasOwn(VIDEO_FILTERS,p)))throw new Error('Filter video tidak tersedia');
  if(!Number.isFinite(Number(intensity)))throw new Error('Intensitas filter video tidak valid');
  const amount=Math.max(0,Math.min(1,Number(intensity)/100));
  if(!chosen.length||!amount)return 'none';
  // Normalize combined strength, so "all filters" doesn't burn highlights.
  const per=amount/Math.sqrt(chosen.length);
  let exposure=0,contrast=0,sat=0,sepia=0,hue=0;
  for(const id of chosen){const f=VIDEO_FILTERS[id];
    exposure+=Math.log(f.brightness)*per;
    contrast+=Math.log(f.contrast)*per;
    sat+=(f.saturate===0?-20:Math.log(f.saturate))*per;
    sepia+=f.sepia*per;hue+=f.hue*per;
  }
  const bound=(v,min,max)=>Math.min(max,Math.max(min,v));
  return `brightness(${bound(Math.exp(exposure),0.85,1.20).toFixed(4)}) `+
    `contrast(${bound(Math.exp(contrast),0.85,1.40).toFixed(4)}) `+
    `saturate(${bound(Math.exp(sat),0,1.65).toFixed(4)}) `+
    `sepia(${bound(sepia,0,0.35).toFixed(4)}) `+
    `hue-rotate(${bound(hue,-20,20).toFixed(3)}deg)`;
}
export function renderFrame(ctx,video,width,height,selected=[],intensity=75){
  if(!video.videoWidth||!video.videoHeight)return false;
  const css=resolveVideoFilter(selected,intensity);
  ctx.save();
  try {
    ctx.clearRect(0,0,width,height);ctx.filter=css;
    const scale=Math.max(width/video.videoWidth,height/video.videoHeight);
    const dw=video.videoWidth*scale,dh=video.videoHeight*scale;
    ctx.drawImage(video,(width-dw)/2,(height-dh)/2,dw,dh);
    return true;
  } finally {ctx.restore();}
}
export function outputVideoSize(width,height,option='source'){
  const ratio=width/height;
  const ceiling=option==='2160'?{w:3840,h:2160}:{w:1920,h:1080};
  const bounds=width>=height?ceiling:{w:ceiling.h,h:ceiling.w};
  const scale=option==='2160'?Math.min(bounds.w/width,bounds.h/height):Math.min(1,bounds.w/width,bounds.h/height);
  const w=Math.max(2,Math.round(width*scale/2)*2),h=Math.max(2,Math.round(height*scale/2)*2);
  return {width:w,height:h,upscaled:scale>1};
}
export function createRecorder(stream,{videoBitsPerSecond}={}){
  const mime=videoMime();if(!mime)throw new Error('Browser tidak mendukung rekaman MediaRecorder. Coba Chrome atau Edge versi terbaru.');
  const session=newVideoCheckpointId();
  const fallback=[];let count=0,staged=0,staging=Promise.resolve(),backupWorking=true;
  let resolveDone,rejectDone;
  const completion=new Promise((ok,fail)=>{resolveDone=ok;rejectDone=fail;});
  let recorder,lastError;
  const wanted=Math.max(2500000,Math.min(45000000,videoBitsPerSecond||6000000));
  for(const bits of [...new Set([wanted,Math.min(wanted,28000000),Math.min(wanted,14000000),6000000])]){
    try {recorder=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:bits});break;}
    catch(error){lastError=error;}
  }
  if(!recorder)throw lastError||new Error('Encoder video tidak mendukung konfigurasi ini');
  recorder.ondataavailable=e=>{
    if(!e.data?.size)return;
    const index=count++,blob=e.data;
    staging=staging.then(async()=>{
      if(backupWorking){
        try{await stageVideoChunk(session,index,blob);staged++;return;}
        catch(err){backupWorking=false;console.warn('BLINK video backup: RAM fallback',err.message);}
      }
      fallback.push({sequence:index,blob});
    });
  };
  recorder.onerror=e=>rejectDone(new Error(e.error?.message||'Gagal merekam video'));
  recorder.onstop=async()=>{
    try {
      await staging;
      const saved=staged?await recoverVideoChunks(session,staged):[];
      const entries=saved.concat(fallback).sort((a,b)=>a.sequence-b.sequence);
      if(entries.length!==count)throw new Error('Bagian rekaman hilang dari backup lokal');
      const b=new Blob(entries.map(c=>c.blob),{type:recorder.mimeType||mime});
      if(!b.size)throw new Error('Browser tidak menghasilkan video');
      resolveDone(b);
    }catch(e){rejectDone(e);}
    finally {await cleanVideoChunks(session,count);}
  };
  recorder.start(1000);
  return {recorder,done:completion,mime,encoderBitrate:recorder.videoBitsPerSecond};
}
