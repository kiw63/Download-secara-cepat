// Explicit per-device accounts. NOT a replacement for the shared BLINK backend.
// No plaintext passwords are stored; accounts cannot sync to the Admin APK.
const USERS = 'blink.offline.accounts.v1';
const SESSION = 'blink.offline.session.v1';
function all(){try{return JSON.parse(localStorage.getItem(USERS)||'{}')}catch{return {}}}
function save(items){localStorage.setItem(USERS,JSON.stringify(items));}
function norm(email){return String(email||'').trim().toLowerCase()}
function hex(bytes){return Array.from(bytes,x=>x.toString(16).padStart(2,'0')).join('')}
function unhex(s){return new Uint8Array((s.match(/.{1,2}/g)||[]).map(v=>parseInt(v,16)))}
async function derive(password,salt){
  if(!crypto?.subtle)throw Error('Keamanan penyimpanan akun tidak tersedia pada perangkat ini.');
  const input=new TextEncoder().encode(password);
  const key=await crypto.subtle.importKey('raw',input,'PBKDF2',false,['deriveBits']);
  const raw=await crypto.subtle.deriveBits({name:'PBKDF2',salt:unhex(salt),iterations:145000,hash:'SHA-256'},key,256);
  return hex(new Uint8Array(raw));
}
function publicUser(record){if(!record)return null;const now=Date.now();
  // Reset free tokens only after a full day, not on every app restart.
  if(now-record.refill>=86400000){record.tokens=3;record.refill=now;const items=all();items[record.email]=record;save(items)}
  return {id:'device-'+record.email,name:record.name,email:record.email,free_tokens:record.tokens,premium_tokens:0,premium_active:false,tier:'free',tokens:record.tokens,device_only:true};
}
export async function registerDeviceAccount(name,email,password){
  email=norm(email);name=String(name||'').trim();
  if(!name||!/^\S+@\S+\.\S+$/.test(email)||password.length<4)throw Error('Isi nama, email valid, dan password minimal 4 karakter.');
  const items=all();if(items[email])throw Error('Email sudah didaftarkan di perangkat ini. Silakan masuk.');
  const salt=hex(crypto.getRandomValues(new Uint8Array(16)));
  items[email]={email,name,salt,digest:await derive(password,salt),tokens:3,refill:Date.now()};save(items);localStorage.setItem(SESSION,email);
  return publicUser(items[email]);
}
export async function loginDeviceAccount(email,password){
  email=norm(email);const r=all()[email];
  // Produce uniform message for missing user or mismatched password.
  if(!r)throw Error('Email atau password tidak sesuai di perangkat ini.');
  if((await derive(password,r.salt))!==r.digest)throw Error('Email atau password tidak sesuai di perangkat ini.');
  localStorage.setItem(SESSION,email);return publicUser(r);
}
export function restoreDeviceAccount(){return publicUser(all()[norm(localStorage.getItem(SESSION))])}
export function logoutDeviceAccount(){localStorage.removeItem(SESSION)}
export function hasDeviceSession(){return Boolean(localStorage.getItem(SESSION))}
export function consumeDeviceToken(){
  const email=norm(localStorage.getItem(SESSION));const items=all();const r=items[email];
  if(!r)throw Error('Sesi lokal tidak ditemukan. Silakan masuk kembali.');
  publicUser(r);if(r.tokens<1)throw Error('Token lokal habis. Token dan Premium online memerlukan server BLINK.');
  r.tokens-=1;items[email]=r;save(items);return publicUser(r);
}
