/** Real NCNN model bridge. No JavaScript super-resolution fallback and no server upload.
 * The APK build fails unless the official Real-ESRGAN weights and Vulkan NCNN SDK
 * are staged into Android assets and the native JNI library is built.
 */
import {decodeImage,PHOTO_PARAMS,PHOTO_TINT} from './media.js';
const BATCH=12288;
let activeJob=null;
export function isNativeRealESRGANReady(){
  try{return window.BLINK_PHOTO_AI?.isReady()===true;}catch{return false;}
}
export async function enhanceNativePhoto(blob,mode='ultra',intensity=100,onProgress=()=>{}){
  if(!isNativeRealESRGANReady())
    throw Error('Real-ESRGAN NCNN asli tidak ditemukan dalam APK. Periksa pemasangan bobot dan engine native saat build.');
  if(activeJob)throw Error('AI sedang memproses foto lain.');
  if(!blob || blob.size===0 || blob.size>32*1048576)throw Error('Foto harus berukuran 1 byte sampai 32 MB.');
  const bridge=window.BLINK_PHOTO_AI;
  const id=bridge.begin();
  if(!id||id.startsWith('ERROR:'))throw Error(id||'Gagal menyiapkan memori foto');
  activeJob=id;
  let timer;
  let pending;
  const finishPromise=new Promise((resolve,reject)=>{
    pending={resolve,reject};
    timer=setTimeout(()=>reject(Error('Pemrosesan NCNN melewati batas 12 menit. Coba input lebih kecil atau perangkat lebih cepat.')),12*60*1000);
  });
  window.BLINK_REAL_AI_DONE=(job,success,message)=>{
    if(job!==id)return;
    if(success)pending.resolve(message);else pending.reject(Error(message||'NCNN gagal menjalankan model'));
  };
  try{
    onProgress(5,'Membersihkan noise dan memulihkan cahaya sebelum AI');
    const bytes=new Uint8Array(await blob.arrayBuffer());
    for(let i=0;i<bytes.length;i+=BATCH){
      const section=bytes.subarray(i,Math.min(i+BATCH,bytes.length));
      // Limit JNI string size; unlike a single 30MB base64 message this does not
      // block WebView long enough to kick the password keyboard or kill rendering.
      let ascii='';for(let n=0;n<section.length;n++)ascii+=String.fromCharCode(section[n]);
      const result=bridge.append(id,btoa(ascii));
      if(result!=='OK')throw Error(result?.replace(/^ERROR:/,'')||'Gagal menyalin foto ke engine NCNN');
      if((i/BATCH)%16===0){onProgress(Math.min(15,5+Math.round(i/bytes.length*10)),'Menyiapkan gambar native');await new Promise(r=>setTimeout(r,0));}
    }
    onProgress(20,'Bersihkan → Cahaya → Deblur → Real-ESRGAN x4 → Tajamkan');
    const profile={params:PHOTO_PARAMS[mode]||PHOTO_PARAMS.ultra,tint:PHOTO_TINT[mode]||PHOTO_TINT.ultra,look:PHOTO_PARAMS[mode]?.look||''};
    bridge.finish(id,Math.max(0,Math.min(150,Number(intensity)||0)),JSON.stringify(profile));
    const report=await finishPromise;
    onProgress(92,'Mengambil hasil AI asli');
    const response=await fetch('./ai-result/'+id+'.jpg?cache='+Date.now(),{cache:'no-store'});
    if(!response.ok)throw Error('File JPEG hasil NCNN tidak dapat diambil dari APK');
    const enhanced=await response.blob();
    if(!enhanced.size || enhanced.type!=='image/jpeg')throw Error('File AI tidak valid');
    const decoded=await decodeImage(enhanced);
    const width=decoded.width,height=decoded.height;decoded.close?.();
    if(width<64||height<64)throw Error('Dimensi output AI salah');
    onProgress(100,'Selesai • NCNN Real-ESRGAN asli • '+report);
    return {blob:enhanced,width,height,method:'Real-ESRGAN x4 NCNN '+report,nativeAI:true};
  }finally{
    clearTimeout(timer);
    if(activeJob===id)activeJob=null;
    if(window.BLINK_REAL_AI_DONE)delete window.BLINK_REAL_AI_DONE;
    try{bridge.cancel(id);}catch{}
  }
}
