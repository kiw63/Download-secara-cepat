/* Configure before building BOTH Android APKs. HTTPS is required. */
window.BLINK_API_BASE = 'https://CHANGE-TO-YOUR-BLINK-BACKEND.example';
