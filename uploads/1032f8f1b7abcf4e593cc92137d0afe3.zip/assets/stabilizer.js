/** BLINK lightweight digital EIS for browser camera.
 * Estimates translational shake using a downsampled luma block matcher,
 * then adjusts source crop. It is not Android optical stabilization.
 */
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
export function estimateTranslation(previous,current,width,height,radius=3){
  if(!previous||previous.length!==current.length)return {dx:0,dy:0,error:Infinity};
  let best={dx:0,dy:0,error:Infinity};
  for(let dy=-radius;dy<=radius;dy++)for(let dx=-radius;dx<=radius;dx++){
    let err=0,n=0;
    for(let y=radius+4;y<height-radius-4;y+=3)for(let x=radius+4;x<width-radius-4;x+=3){
      err+=Math.abs(previous[y*width+x]-current[(y+dy)*width+x+dx]);n++;
    }
    const error=err/Math.max(1,n);
    if(error<best.error)best={dx,dy,error};
  }
  return best;
}
export function createDigitalStabilizer(){
  const low=document.createElement('canvas');low.width=96;low.height=54;
  const ctx=low.getContext('2d',{alpha:false,willReadFrequently:true});
  let previous=null,dx=0,dy=0,step=0;
  return {
    reset(){previous=null;dx=dy=step=0;},
    estimate(source){
      if(!source.videoWidth||!source.videoHeight)return {x:0,y:0,scale:1};
      if(++step%2!==0)return {x:dx,y:dy,scale:.91};
      ctx.drawImage(source,0,0,96,54);
      const image=ctx.getImageData(0,0,96,54).data;
      const current=new Uint8Array(96*54);
      for(let i=0;i<current.length;i++)current[i]=(image[i*4]*3+image[i*4+1]*6+image[i*4+2])/10;
      if(previous){
        const motion=estimateTranslation(previous,current,96,54,3);
        // Reject scene cuts or exposure changes; do not over-correct panning.
        if(motion.error<38){
          dx=clamp(dx*.84-motion.dx/96*.18,-.037,.037);
          dy=clamp(dy*.84-motion.dy/54*.18,-.037,.037);
        }else{dx*=.75;dy*=.75;}
      }
      previous=current;return {x:dx,y:dy,scale:.91};
    }
  };
}
