/** BLINK V6.2 Super HD photo finishing (offline, non-generative).
 * Multi-scale luminance reconstruction at SOURCE resolution: 3/5-tap Gaussian
 * bands, edge-aware sharpening, flat-region noise suppression and gentle
 * local contrast. RGB chroma is not sharpened independently (avoids color halos).
 * Tiled callers MUST include a two-pixel halo for seamless seams.
 * This is not a pretrained generative super-resolution model.
 */
import {photoLookRGB} from './photo-looks.js';
export const clamp=(x,min=0,max=255)=>Math.max(min,Math.min(max,x));
export function enhancePhotoPatch(src,width,height,{params,tint,strength=1,detail=1,
  neural=null,neuralWidth=0,neuralHeight=0,offsetX=0,offsetY=0,outWidth=width,outHeight=height}={}){
  if(!params||!tint)throw new Error('Profil foto tidak valid');
  if(width<1||height<1||src.length!==width*height*4)throw new Error('Pixel foto tidak valid');
  strength=clamp(Number(strength)||0,0,1.5);
  detail=clamp(Number(detail)||0,0,2.6);
  if(strength===0)return new Uint8ClampedArray(src);
  const n=width*height,tone=new Uint8ClampedArray(src.length);
  const lum=new Float32Array(n),h3=new Float32Array(n),h5=new Float32Array(n),looked=[0,0,0];
  for(let p=0;p<n;p++){
    const i=p*4;let r=src[i]/255,g=src[i+1]/255,b=src[i+2]/255;
    r=Math.pow(Math.min(1,r*params.gain),params.gamma);
    g=Math.pow(Math.min(1,g*params.gain),params.gamma);
    b=Math.pow(Math.min(1,b*params.gain),params.gamma);
    const y=.2126*r+.7152*g+.0722*b;
    r=(y+(r-y)*params.sat-.5)*params.contrast+.5;
    g=(y+(g-y)*params.sat-.5)*params.contrast+.5;
    b=(y+(b-y)*params.sat-.5)*params.contrast+.5;
    photoLookRGB(255*r*tint[0],255*g*tint[1],255*b*tint[2],params.look,looked);
    tone[i]=clamp(looked[0]);tone[i+1]=clamp(looked[1]);tone[i+2]=clamp(looked[2]);tone[i+3]=255;
    lum[p]=.2126*src[i]+.7152*src[i+1]+.0722*src[i+2];
  }
  // Separable Gaussian: inexpensive 3x3 and 5x5 kernels; no whole-image allocation.
  for(let y=0;y<height;y++){
    const row=y*width;
    for(let x=0;x<width;x++){
      const a=row+Math.max(0,x-2),b=row+Math.max(0,x-1),c=row+x,
        d=row+Math.min(width-1,x+1),e=row+Math.min(width-1,x+2);
      h3[c]=(lum[b]+2*lum[c]+lum[d])*.25;
      h5[c]=(lum[a]+4*lum[b]+6*lum[c]+4*lum[d]+lum[e])*.0625;
    }
  }
  const out=new Uint8ClampedArray(src.length);
  const denoise=clamp(Number(params.denoise)||0,0,0.8);
  for(let y=0;y<height;y++){
    const a=Math.max(0,y-2)*width,b=Math.max(0,y-1)*width,
      c=y*width,d=Math.min(height-1,y+1)*width,e=Math.min(height-1,y+2)*width;
    for(let x=0;x<width;x++){
      const p=c+x,i=p*4,yy=lum[p];
      const g3=(h3[b+x]+2*h3[p]+h3[d+x])*.25;
      const g5=(h5[a+x]+4*h5[b+x]+6*h5[p]+4*h5[d+x]+h5[e+x])*.0625;
      const fine=yy-g3,mid=g3-g5;
      const fineAbs=Math.abs(fine),midAbs=Math.abs(mid);
      // Ignore low-level sensor grain; enhance texture and edges with soft knee.
      const texture=clamp((fineAbs-(3.3+denoise*3))/9.0,0,1);
      const structure=clamp((midAbs-1.1)/5,0,1);
      const haloGuard=1/(1+Math.pow(Math.max(0,fineAbs-27)/42,2));
      const detailFine=fine*detail*1.14*texture*haloGuard;
      const detailMid=mid*detail*.98*structure;
      const localContrast=clamp(yy-g5,-32,32)*detail*.16*structure;
      const reduceNoise=fine*denoise*(1-texture)*.75;
      const neuralCorrection=neural?clamp(neural[p]-128,-18,18)*.9:0;
      const shift=clamp(detailFine+detailMid+localContrast-reduceNoise+neuralCorrection,-48,48)*strength;
      for(let k=0;k<3;k++)out[i+k]=clamp(src[i+k]+(tone[i+k]-src[i+k])*strength+shift);
      out[i+3]=255;
    }
  }
  return out;
}
