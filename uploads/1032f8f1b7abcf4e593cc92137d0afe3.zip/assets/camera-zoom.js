/** BLINK Android camera zoom: Camera2-supported hardware zoom, digital crop fallback.
 * 50x is a UI control limit; optical zoom and detail depend on the physical camera. */
export async function applyZoomToTrack(track, requested=1){
  requested=Math.max(1,Math.min(50,Number(requested)||1));
  const cap=typeof track.getCapabilities==='function'?track.getCapabilities():{};
  const limit=cap.zoom&&Number.isFinite(cap.zoom.max)?Math.max(1,cap.zoom.max):1;
  const hardware=Math.min(requested,limit);
  let usedHardware=1;
  if(limit>1){try{await track.applyConstraints({advanced:[{zoom:hardware}]});usedHardware=hardware;}catch(error){console.warn('Hardware zoom unsupported:',error);}}
  return {hardware:usedHardware,digital:Math.max(1,requested/usedHardware)};
}
export async function cropZoomedPhoto(blob,digital){
  digital=Math.max(1,Math.min(50,Number(digital)||1));
  if(digital<=1.001)return blob;
  const src=typeof createImageBitmap==='function'?await createImageBitmap(blob):await new Promise((ok,bad)=>{const i=new Image(),u=URL.createObjectURL(blob);i.onload=()=>{URL.revokeObjectURL(u);ok(i)};i.onerror=bad;i.src=u});
  try{
    const w=src.width,h=src.height,sw=w/digital,sh=h/digital;
    const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;
    const ctx=canvas.getContext('2d',{alpha:false});ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';
    ctx.drawImage(src,(w-sw)/2,(h-sh)/2,sw,sh,0,0,w,h);
    return await new Promise((ok,bad)=>canvas.toBlob(b=>b?.size?ok(b):bad(Error('Gagal menyimpan zoom foto')),'image/jpeg',.985));
  }finally{src.close?.()}
}
