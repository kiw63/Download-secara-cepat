/** BLINK original photographic color signatures. Not imported third-party LUTs.
 * Operates after the base tone curve and BEFORE strength blending to preserve 0% identity.
 * Inputs/outputs 0..255, no allocations in full-image callers other than returned triplet.
 */
const smooth=(a,b,x)=>{const t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t);};
const clip=x=>Math.max(0,Math.min(255,x));
export function photoLookRGB(r,g,b,look,out=[0,0,0]){
  if(!look){out[0]=r;out[1]=g;out[2]=b;return out;}
  const y=(.2126*r+.7152*g+.0722*b)/255;
  const shadow=(1-y)*(1-y),highlight=y*y;
  const green=smooth(.02,.18,(g-Math.max(r,b))/255+.015);
  const blue=smooth(.018,.20,(b-r)/255)*smooth(-.10,.12,(b-g)/255);
  const warm=smooth(.01,.16,(r-b)/255);
  const neutral=1-smooth(.035,.16,(Math.max(r,g,b)-Math.min(r,g,b))/255);
  switch(look){
    case 'enhance':out[0]=clip(r+6*shadow);out[1]=clip(g+7*shadow);out[2]=clip(b+7*shadow);return out;
    case 'miles17':out[0]=clip(r+6*highlight-2*shadow);out[1]=clip(g+2*highlight+2*shadow);out[2]=clip(b+7*shadow-3*highlight);return out;
    case 'alam':out[0]=clip(r-9*green-5*blue);out[1]=clip(g+30*green+5*blue);out[2]=clip(b-5*green+28*blue);return out;
    case 'bunga':out[0]=clip(r+7+7*warm);out[1]=clip(g+7);out[2]=clip(b+7+5*warm);return out;
    case 'senja':out[0]=clip(r+22*highlight+8*warm);out[1]=clip(g+9*highlight+2*warm);out[2]=clip(b-20*highlight-8*warm);return out;
    case 'crystal':out[0]=clip(r+4*highlight);out[1]=clip(g+5*highlight+2*shadow);out[2]=clip(b+7*highlight+4*shadow);return out;
    case 'hd4k':out[0]=clip(r+2*shadow);out[1]=clip(g+2*shadow);out[2]=clip(b+2*shadow);return out;
    case 'cinematic':out[0]=clip(r+11*highlight-7*shadow);out[1]=clip(g+2*highlight+5*shadow);out[2]=clip(b+11*shadow-5*highlight);return out;
    case 'putih':out[0]=clip(r-14*neutral*warm+9*shadow);out[1]=clip(g+5*neutral+11*shadow);out[2]=clip(b+19*neutral*warm+13*shadow);return out;
    case 'vividplus':out[0]=clip(r+8*highlight-4*blue);out[1]=clip(g+22*green+4*highlight);out[2]=clip(b+19*blue+2*highlight);return out;
    case 'creamy':out[0]=clip(r+12*highlight+10*shadow);out[1]=clip(g+8*highlight+6*shadow);out[2]=clip(b+4*highlight-4*shadow);return out;
    default:out[0]=r;out[1]=g;out[2]=b;return out;
  }
}
