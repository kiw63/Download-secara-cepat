import {captureStill, downloadBlob, decodeImage, readableBytes, renderFrame, localEnhance, videoMime, createRecorder} from './media.js';
import {enhanceOnDevicePhoto} from './ondevice-ai.js';
import {createVideoRenderer} from './video-renderer.js';
import {createFilterGallery} from './filter-gallery.js';
import {BLINK_PLANS, accessLevel, money} from './plans.js';
import {createDigitalStabilizer} from './stabilizer.js';
import {applyZoomToTrack, cropZoomedPhoto} from './camera-zoom.js';
import {registerDeviceAccount,loginDeviceAccount,restoreDeviceAccount,logoutDeviceAccount,hasDeviceSession,consumeDeviceToken} from './offline-auth.js';
const $=id=>document.getElementById(id);
let token=localStorage.getItem('blink.session')||'', user=null, stream=null, facing='environment', frameLoop=0, recorder=null, videoOutput=null, processedPhoto=null, originalPhoto=null, livePhoto=null, liveMotion=null, chosenPlan=null, isBusy=false, activeCaptureFps=0, activeAudio=false, renderFrameCount=0, lastFrameMeasure=0, videoRenderer=null, preparingRecord=false, requestedZoom=1, digitalZoom=1, lastPaintTime=0, cameraRequestKey='';
let photoGallery,videoGallery; let stabilizer=createDigitalStabilizer();
let activeCanvasTrack=null;
let frameSource=null,frameCallbackType='raf';
let apiRoot=localStorage.getItem('blink.api')||window.BLINK_API_BASE||'';
function connectedMode(){return /^https:\/\/[^\s/]+\.[^\s/]+/i.test(apiRoot) && !/CHANGE-TO|\.example(?=\/|$)/i.test(apiRoot);}
function localMode(){return !connectedMode()}
function explainMode(){
  $('auth-mode').textContent=localMode()
    ?'Mode lokal: akun disimpan di HP ini. Koneksi server dibutuhkan untuk token bersama, pembayaran QRIS dan sinkronisasi admin.'
    :'Akun terhubung ke layanan BLINK. Masukkan email dan password.';
}

function toast(m,error=false){const e=$('toast');e.textContent=m;e.className='toast show'+(error?' error':'');clearTimeout(toast.timer);toast.timer=setTimeout(()=>e.className='toast',5500)}
function status(id,m){$(id).textContent=m}
function showScreen(name){document.querySelectorAll('body>.screen').forEach(el=>el.classList.toggle('show',el.id===name))}
function navigate(name){document.querySelectorAll('.page').forEach(el=>el.classList.toggle('active',el.id==='page-'+name));document.querySelectorAll('.bottomnav button').forEach(b=>b.classList.toggle('active',b.dataset.view===name));if(name==='plans')void loadPlans();if(name==='payment')void refreshOrders();if(name==='account')refreshAccount(); if(name==='camera'&&stream)$('camera-feed').play().catch(()=>{});if((name==='video'||name==='live')&&stream)startFrames();}
async function api(path,{method='GET',body,auth=true,timeoutMs=10000}={}){
  if(!connectedMode()) throw Error('Server BLINK belum aktif. Kamu bisa menggunakan akun lokal untuk kamera.');
  const head={'Content-Type':'application/json'};if(auth&&token)head.Authorization='Bearer '+token;
  let res;const timeout=new AbortController();const timer=setTimeout(()=>timeout.abort(),timeoutMs);
  try{res=await fetch(apiRoot.replace(/\/$/,'')+path,{method,headers:head,body:body===undefined?undefined:JSON.stringify(body),signal:timeout.signal})}
  catch{throw Error('Koneksi server BLINK gagal. Periksa jaringan atau gunakan akun lokal jika server belum tersedia.');}
  finally{clearTimeout(timer);}
  const data=await res.json().catch(()=>({}));if(!res.ok)throw Error(data.detail||`Layanan gagal (${res.status})`);return data;
}
function updateWallet(){const balance=user?.tokens??'—';$('tokens').textContent=balance+' token';const tier=accessLevel(user);if(photoGallery)photoGallery.setTier(tier);if(videoGallery)videoGallery.setTier(tier);const photo4k=$('photo-quality').querySelector('[value="4k"]');photo4k.disabled=tier<2;if(tier<2&&$('photo-quality').value==='4k')$('photo-quality').value='original';}
async function checkRealESRGAN(){
  if(localMode())return;
  const option=[...$('photo-quality').options].find(o=>o.value==='real-esrgan');
  if(!option)return;
  option.disabled=true;
  try{
    const st=await api('/api/ai/status',{auth:false});
    if(st?.trained_model_ready && st.engine==='RealESRGAN_x4plus'){
      option.disabled=false;option.textContent='Real-ESRGAN x4 Server — Ultra 4K';
    }else{option.textContent='Real-ESRGAN x4 Server — menunggu bobot asli';}
  }catch{option.textContent='Real-ESRGAN x4 Server — server AI belum terhubung';}
}

async function refreshMe(){
  if(localMode()) {user=restoreDeviceAccount();if(!user)throw Error('Belum masuk dengan akun lokal.');}
  else {if(!token)throw Error('Belum login');user=await api('/api/me');}
  updateWallet();return user;
}
async function launchStudio(){
  showScreen('studio');setupFilterGalleries();navigate('camera');
  if(!localMode())void checkRealESRGAN();
  void startCamera().catch(e=>toast('Izinkan kamera agar BLINK dapat mengambil foto: '+e.message,true));
}
async function enterApp(){
  if(localMode()){
    if(hasDeviceSession()){
      try{await refreshMe();await launchStudio();return;}catch(e){logoutDeviceAccount();toast(e.message,true)}
    }
  }else if(token){
    try{await refreshMe();await launchStudio();return;}
    catch(e){if(!/koneksi|server|internet/i.test(e.message)){token='';localStorage.removeItem('blink.session')}toast(e.message,true)}
  }
  explainMode();showScreen('auth');
}
$('enter').onclick=()=>void enterApp();
$('show-register').onclick=()=>{$('login-form').hidden=true;$('register-form').hidden=false;status('auth-title','Daftar Akun BLINK');status('auth-status','');explainMode();};
$('show-login').onclick=()=>{$('login-form').hidden=false;$('register-form').hidden=true;status('auth-title','Masuk ke BLINK');status('auth-status','');explainMode();};
$('register-form').onsubmit=async e=>{
  e.preventDefault();status('auth-status','');
  const submit=$('register-form').querySelector('[type=submit]');submit.disabled=true;
  try{
    if(localMode()){
      user=await registerDeviceAccount($('reg-name').value,$('reg-email').value,$('reg-pass').value);
      updateWallet();$('reg-pass').value='';await launchStudio();
    }else{
      await api('/api/auth/register',{method:'POST',body:{name:$('reg-name').value,email:$('reg-email').value,password:$('reg-pass').value},auth:false});
      toast('Akun berhasil dibuat. Silakan masuk.');$('login-email').value=$('reg-email').value;$('show-login').click();
    }
  }catch(err){status('auth-status',err.message)}finally{submit.disabled=false}
};
$('login-form').onsubmit=async e=>{
  e.preventDefault();status('auth-status','');
  const submit=$('login-form').querySelector('[type=submit]');submit.disabled=true;
  try{
    if(localMode()) user=await loginDeviceAccount($('login-email').value,$('login-pass').value);
    else{
      const result=await api('/api/auth/login',{method:'POST',body:{email:$('login-email').value,password:$('login-pass').value},auth:false});
      token=result.token;localStorage.setItem('blink.session',token);user=await api('/api/me');
    }
    updateWallet();$('login-pass').value='';await launchStudio();
  }catch(err){status('auth-status',err.message)}finally{submit.disabled=false}
};
$('logout').onclick=()=>{
  if(!localMode()&&token)void api('/api/auth/logout',{method:'POST'}).catch(()=>{});
  token='';user=null;localStorage.removeItem('blink.session');logoutDeviceAccount();stopCamera();showScreen('auth');$('show-login').click();toast('Kamu sudah keluar.');
};
$('server-url').value=apiRoot;
$('server-save').onclick=()=>{
  const v=$('server-url').value.trim().replace(/\/$/,'');
  if(!v.startsWith('https://')||/CHANGE-TO|\.example(?=\/|$)/i.test(v))return toast('Alamat server HTTPS BLINK yang benar diperlukan.',true);
  apiRoot=v;localStorage.setItem('blink.api',v);token='';localStorage.removeItem('blink.session');user=null;
  stopCamera();explainMode();showScreen('auth');$('show-login').click();toast('Alamat server tersimpan. Silakan masuk menggunakan akun server.');
};
function refreshAccount(){
  if(!user)return;
  $('account-info').textContent=`${user.name} (${user.email}) • ${user.tier.toUpperCase()} • ${user.tokens} token tersedia`;
  $('server-url').value=apiRoot;
  $('account-mode').textContent=localMode()?'Mode lokal: akun hanya berlaku di HP ini. Admin dan QRIS belum tersinkron.':'Akun, token, dan pembayaran menggunakan server BLINK terhubung.';
}
for(const b of document.querySelectorAll('[data-view]'))b.onclick=()=>navigate(b.dataset.view);
$('upgrade').onclick=()=>navigate('plans');$('back-studio').onclick=()=>navigate('camera');$('back-plans').onclick=()=>navigate('plans');

// Camera is the primary media source. Android requests CAMERA permission when this API runs.
async function startCamera(audio=false){
  if(recorder?.state==='recording')throw Error('Hentikan rekaman sebelum mengganti kamera.');
  const requestedFps=$('video-fps').value==='60'?60:30;
  const videoTier=$('video-quality').value;
  const requestKey=[requestedFps,videoTier,Boolean(audio)].join(':');
  if(stream&&stream.active && cameraRequestKey===requestKey)return stream;
  stopCamera();
  const fps=requestedFps;
  // Request practical source dimensions: pushing 4K camera frames through a live
  // WebGL/CPU filter every preview frame can stall Android WebView.
  // Source resolution and actual FPS are always reported, never invented.
  const recording4k=videoTier==='2160'&&fps<=30&&accessLevel(user)>=2;
  const cameraW=recording4k?3840:fps>=60?1280:1920;
  const cameraH=recording4k?2160:fps>=60?720:1080;
  const video={facingMode:{ideal:facing},width:{ideal:cameraW},height:{ideal:cameraH},frameRate:{ideal:fps}};
  try{stream=await navigator.mediaDevices.getUserMedia({video,audio})}
  catch(error){if(error.name==='OverconstrainedError'||error.name==='NotReadableError'){stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:facing}},audio})}else{status('camera-status','Izin kamera diperlukan: '+error.message);throw error}}
  const v=$('camera-feed');v.srcObject=stream;await v.play();const extra=$('video-feed');extra.srcObject=stream;extra.play().catch(()=>{});$('camera-empty').hidden=true;$('video-placeholder').hidden=true;
  activeCaptureFps=Math.min(fps,Math.round(stream.getVideoTracks()[0].getSettings().frameRate||fps)); activeAudio=Boolean(stream.getAudioTracks().length);cameraRequestKey=requestKey;
  await updateZoomOnCamera();
  const cfg=stream.getVideoTracks()[0].getSettings();$('cam-info').textContent=`${cfg.width||v.videoWidth}×${cfg.height||v.videoHeight} · ${Math.round(cfg.frameRate||0)} FPS`;
  $('snap').disabled=false;$('video-record').disabled=false;
  status('camera-status',`Kamera aktif ${cfg.width||v.videoWidth}×${cfg.height||v.videoHeight} @ ${Math.round(cfg.frameRate||0)} FPS. Ketuk tombol foto untuk memproses otomatis.`);
  startFrames();return stream;
}
function stopCamera(){stabilizer.reset();activeCaptureFps=0;activeAudio=false;cameraRequestKey='';lastPaintTime=0;if(frameLoop){if(frameCallbackType==='video'&&frameSource?.cancelVideoFrameCallback)frameSource.cancelVideoFrameCallback(frameLoop);else cancelAnimationFrame(frameLoop)}frameLoop=0;frameSource=null;if(stream){stream.getTracks().forEach(t=>t.stop());stream=null}$('camera-feed').srcObject=null;$('video-feed').srcObject=null;$('camera-empty').hidden=false;$('video-placeholder').hidden=false;$('snap').disabled=true;$('video-record').disabled=true}
$('camera-start').onclick=()=>void startCamera().catch(e=>toast(e.message,true));$('camera-stop').onclick=stopCamera;
$('flip').onclick=()=>{if(recorder?.state==='recording')return toast('Hentikan rekaman sebelum mengganti kamera.',true);facing=facing==='environment'?'user':'environment';void startCamera().catch(e=>toast(e.message,true))};
$('video-init').onclick=()=>void startCamera().catch(e=>toast(e.message,true));
async function updateZoomOnCamera(){
  if(!stream)return;
  const track=stream.getVideoTracks()[0];
  const z=await applyZoomToTrack(track,requestedZoom);
  digitalZoom=z.digital;
  $('camera-feed').style.transform=`scale(${digitalZoom})`;
  $('zoom-photo-value').textContent=requestedZoom.toFixed(1)+'×'+(digitalZoom>1.001?' digital':'');
  $('zoom-video-value').textContent=requestedZoom.toFixed(1)+'×'+(digitalZoom>1.001?' digital':'');
}
let zoomUpdate=Promise.resolve();
function chooseZoom(value){
  requestedZoom=Math.max(1,Math.min(50,Number(value)||1));
  $('zoom-photo-slider').value=String(requestedZoom);
  $('zoom-video-slider').value=String(requestedZoom);
  $('zoom-photo-value').textContent=$('zoom-video-value').textContent=requestedZoom.toFixed(1)+'×';
  // Serialize Android Camera2 applyConstraints requests: overlapping commands
  // can cause camera stalls during fast slider gestures.
  zoomUpdate=zoomUpdate.catch(()=>{}).then(()=>updateZoomOnCamera()).catch(e=>console.warn('BLINK zoom',e));
}
$('zoom-photo-slider').oninput=e=>chooseZoom(e.target.value);
$('zoom-video-slider').oninput=e=>chooseZoom(e.target.value);

function selectedFilter(){const p=$('video-preset').value;return p==='natural'?[]:[p]}
function startFrames(){
  if(frameLoop){if(frameCallbackType==='video'&&frameSource?.cancelVideoFrameCallback)frameSource.cancelVideoFrameCallback(frameLoop);else cancelAnimationFrame(frameLoop)}
  frameLoop=0;
  const canvas=$('video-canvas');
  if(!videoRenderer)videoRenderer=createVideoRenderer(canvas);
  const vid=$('video-feed').videoWidth?$('video-feed'):$('camera-feed');
  // Decode once per camera frame; don't re-upload the same frame 2-4 times on
  // Android 90/120Hz refresh-rate displays. RAF is a compatibility fallback.
  const useVideoCallback=typeof vid.requestVideoFrameCallback==='function';
  frameCallbackType=useVideoCallback?'video':'raf';frameSource=vid;
  const queue=()=>{
    if(!stream)return;
    frameLoop=useVideoCallback?vid.requestVideoFrameCallback(tick):requestAnimationFrame(tick);
  };
  function tick(){
    if(!stream)return;
    queue();
    if(!$('page-video').classList.contains('active') && !$('page-live').classList.contains('active') && recorder?.state!=='recording' && !preparingRecord)return;
    if(!vid.videoWidth||!vid.videoHeight)return;
    const fps=recorder?.state==='recording'||preparingRecord?Math.max(1,Math.min(activeCaptureFps,Number($('video-fps').value))):30;
    const now=performance.now();
    if(now-lastPaintTime<1000/fps-1.5)return;
    lastPaintTime=now;
    const captureActive=preparingRecord||recorder?.state==='recording';
    const tier=accessLevel(user),selected=$('video-quality').value;
    let res=captureActive?(tier===0?720:(selected==='2160'&&tier>=2?2160:selected==='1080'?1080:720)):720;
    // CPU 4K rendering makes synthetic FPS/pixelation worse. Never upscale a
    // 960px CPU buffer to 4K and call it an enhanced capture.
    const portrait=vid.videoHeight>vid.videoWidth;
    const sourceShort=Math.min(vid.videoWidth,vid.videoHeight);
    const sourceLong=Math.max(vid.videoWidth,vid.videoHeight);
    if(videoRenderer.stats().renderType.includes('CPU')){
      // Fallback operates at <=1280 on its long edge. Match the *recorded*
      // canvas dimensions instead of upscaling low-res CPU pixels on tall phones.
      res=Math.min(res,720,1280*sourceShort/sourceLong);
    }
    res=Math.min(res,Math.max(2,sourceShort)); // no fake pixels in on-device recorder
    const targetW=Math.round((portrait?res:res*vid.videoWidth/vid.videoHeight)/2)*2;
    const targetH=Math.round((portrait?res*vid.videoHeight/vid.videoWidth:res)/2)*2;
    try {
      // Stabilizer uses frame sampling; only on GPU and at <=1080p in real-time.
      const adjustment=$('video-stabilizer').checked && res<=1080 && !videoRenderer.stats().renderType.includes('CPU')
        ?stabilizer.estimate(vid):{x:0,y:0,scale:1};
      adjustment.scale=(adjustment.scale||1)/digitalZoom;
      if(videoRenderer.render(vid,targetW,targetH,$('video-preset').value,Number($('video-intensity').value),adjustment)){
        renderFrameCount++;
        if(recorder?.state==='recording' && activeCanvasTrack)activeCanvasTrack.requestFrame();
      }
    }catch(e){stopCamera();status('video-status','Renderer video gagal: '+e.message);toast('Filter video gagal diterapkan: '+e.message,true);}
  }
  queue();
}
// This preview is approximate; the full-resolution photo engine independently
// applies its color grade to actual saved JPEG pixels after the shutter.
const PHOTO_PREVIEW={
  sharp:'contrast(1.14) saturate(1.08)',ultra:'contrast(1.2) saturate(1.16)',
  clean:'contrast(1.055) saturate(1.04)',night:'brightness(1.2) contrast(1.09)',
  vivid:'contrast(1.1) saturate(1.25)',portrait:'brightness(1.025) saturate(1.02)',
  analog:'sepia(.28) saturate(.78)',retro:'sepia(.4) contrast(1.12) saturate(.8)',
  blackwhite:'grayscale(1) contrast(1.2)',pastel:'brightness(1.12) contrast(.94) saturate(.83)',
  golden:'sepia(.22) saturate(1.2)',icy:'hue-rotate(8deg) saturate(.85)',
  moody:'brightness(.91) contrast(1.2)',teal:'hue-rotate(13deg) contrast(1.12)',
  travel:'brightness(1.08) saturate(1.17)',food:'brightness(1.12) saturate(1.28)',
  beauty:'brightness(1.05) contrast(1.02)',glow:'brightness(1.11) contrast(.95)',
  nightblue:'hue-rotate(16deg) contrast(1.1)',street:'contrast(1.27) saturate(.9)',
  fresh:'brightness(1.08) saturate(1.23)'
};
function updatePhotoPreview(){
  const m=$('photo-mode').value;
  $('camera-feed').style.filter=Number($('photo-intensity').value)===0?'none':(PHOTO_PREVIEW[m]||'none');
  status('camera-status',`Preset ${$('photo-mode').selectedOptions[0].text} dipilih. Saat tombol foto ditekan, hasil akan diproses dan disimpan memakai preset ini.`);
}
$('photo-mode').onchange=updatePhotoPreview;
function setupFilterGalleries(){
 if(photoGallery&&videoGallery)return;
photoGallery=createFilterGallery({kind:'photo',containerId:'photo-gallery',categoriesId:'photo-categories',select:$('photo-mode'),onSelect:(p,locked)=>{if(locked){toast('Filter '+p.name+' tersedia pada paket '+['Free','Plus','Pro','Pro Max'][p.minTier]+'.',true);navigate('plans');}else status('photo-filter-name',p.name)},tier:accessLevel(user)});
videoGallery=createFilterGallery({kind:'video',containerId:'video-gallery',categoriesId:'video-categories',select:$('video-preset'),onSelect:(p,locked)=>{if(locked){toast('Filter '+p.name+' tersedia pada paket '+['Free','Plus','Pro','Pro Max'][p.minTier]+'.',true);navigate('plans');}else status('video-filter-name',p.name)},tier:accessLevel(user)});
$('photo-intensity').oninput=()=>{status('photo-intensity-number',$('photo-intensity').value+'%');updatePhotoPreview();};
}
updatePhotoPreview();
$('video-preset').onchange=()=>status('video-status','Filter '+$('video-preset').selectedOptions[0].text+' diterapkan pada pratinjau dan hasil rekaman.');
$('video-intensity').oninput=()=>{status('intensity-number',$('video-intensity').value+'%');status('video-status','Intensitas filter: '+$('video-intensity').value+'%.');};
$('video-stabilizer').onchange=()=>{stabilizer.reset();status('video-status',$('video-stabilizer').checked?'Stabilisasi digital diaktifkan (crop kecil pada frame).':'Stabilisasi nonaktif.');};
$('video-fps').onchange=()=>{if(stream&&recorder?.state!=='recording')void startCamera(activeAudio).catch(e=>toast(e.message,true));};
$('video-quality').onchange=()=>{if(stream&&recorder?.state!=='recording')void startCamera(activeAudio).catch(e=>toast(e.message,true));};
async function encodeBase64(blob){
  const raw=new Uint8Array(await blob.arrayBuffer());
  let bytes='';for(let i=0;i<raw.length;i+=32768)bytes+=String.fromCharCode(...raw.subarray(i,i+32768));
  return btoa(bytes);
}
function decodeBase64Photo(encoded,mime='image/jpeg'){
  const binary=atob(encoded),chunk=32768,parts=[];
  for(let i=0;i<binary.length;i+=chunk){const s=binary.slice(i,i+chunk);const a=new Uint8Array(s.length);for(let j=0;j<s.length;j++)a[j]=s.charCodeAt(j);parts.push(a);}
  return new Blob(parts,{type:mime});
}
async function processStill(blob,mode,step){
  status(step,'Menjaga detail foto sumber tanpa kompresi perantara…');
  const choice=$('photo-quality')?.value || 'original';
  if(choice==='4k'&&accessLevel(user)<2)throw Error('Output 4K disediakan untuk BLINK Pro dan Pro Max.');
  if(choice==='real-esrgan'){
    if(blob.size>12*1048576)throw Error('Foto untuk Real-ESRGAN maksimal 12 MB; turunkan resolusi kamera sumber.');
    status(step,'Mengirim foto ke server BLINK untuk inferensi Real-ESRGAN x4…');
    // Server MUST execute trained RealESRGAN_x4plus and charge token only after success.
    // A missing checkpoint is a hard error; never show local interpolation as ESRGAN.
    const data=await api('/api/photo/realesrgan',{method:'POST',body:{image_base64:await encodeBase64(blob)}});
    if(data.engine!=='RealESRGAN_x4plus'||!data.image_base64||!data.model_sha256)throw Error('Server tidak memberikan bukti inferensi Real-ESRGAN asli.');
    const trainedBlob=decodeBase64Photo(data.image_base64,data.mime);
    // Grade AFTER trained restoration: don't feed lossy pre-sharpened JPEG into AI.
    const strength=Number($('photo-intensity').value);
    const finished=strength>0?await localEnhance(trainedBlob,mode,'original','image/jpeg',strength)
      :{blob:trainedBlob,width:data.width,height:data.height};
    return {...finished,model:data.engine,modelHash:data.model_sha256,
      method:'RealESRGAN_x4plus server + warna foto',remoteCharged:true,remainingTokens:data.tokens};
  }
  const resolution=choice==='original'?'original':'4k';
  return enhanceOnDevicePhoto(blob,mode,'image/jpeg',{resolution,backup:false,
    intensity:Number($('photo-intensity').value),
    onProgress:(pct,label)=>status(step,`Memproses foto lokal: ${pct}% · ${label}`)});
}
async function photoPixelDelta(before,after){
  const [a,b]=await Promise.all([decodeImage(before),decodeImage(after)]);
  try {
    const canvas=document.createElement('canvas');canvas.width=80;canvas.height=80;
    const ctx=canvas.getContext('2d',{willReadFrequently:true});
    ctx.drawImage(a,0,0,80,80);const left=ctx.getImageData(0,0,80,80).data;
    ctx.clearRect(0,0,80,80);ctx.drawImage(b,0,0,80,80);const right=ctx.getImageData(0,0,80,80).data;
    let delta=0;for(let i=0;i<left.length;i+=4)for(let c=0;c<3;c++)delta+=Math.abs(left[i+c]-right[i+c]);
    return delta/(80*80*3);
  }finally{a.close?.();b.close?.();}
}
$('snap').onclick=async()=>{
  if(isBusy)return;if(!user||user.tokens<=0){toast('Token tidak tersedia. Lihat paket Upgrade.',true);navigate('plans');return;}isBusy=true;$('snap').disabled=true;
  try{if(!stream)await startCamera();originalPhoto=await captureStill($('camera-feed'));
    if(digitalZoom>1.001){originalPhoto={...originalPhoto,blob:await cropZoomedPhoto(originalPhoto.blob,digitalZoom),source:originalPhoto.source+'-digital-zoom'};}
    $('photo-before').src=URL.createObjectURL(originalPhoto.blob);$('photo-result').hidden=false;
    const ai=await processStill(originalPhoto.blob,$('photo-mode').value,'camera-status');
    // Never present an unchanged original as an enhanced output after processing fails.
    const pixelDelta=await photoPixelDelta(originalPhoto.blob,ai.blob);
    if(pixelDelta<0.8 && !ai.remoteCharged && Number($('photo-intensity').value)>0)throw Error('Hasil foto hampir identik dengan sumber. Pilih mode lain; token lokal belum dipotong.');
    processedPhoto=ai;$('photo-after').src=URL.createObjectURL(ai.blob);
    ai.pixelDelta=pixelDelta;
    status('photo-detail',`BLINK Enhance ${ai.method||"CNN lokal"} • kamera ${originalPhoto.width} × ${originalPhoto.height} • hasil ${ai.width} × ${ai.height} px • ${readableBytes(ai.blob.size)} • selisih piksel rata-rata ${ai.pixelDelta.toFixed(1)}/255`);
    try{if(ai.remoteCharged){user=await api('/api/me')}else if(localMode()){user=consumeDeviceToken()}else{user=await api('/api/tokens/consume',{method:'POST'})}updateWallet()}catch(e){toast('Hasil foto sudah jadi, namun token gagal disinkronkan: '+e.message,true)}
    status('camera-status','Pemrosesan selesai. Bandingkan hasil asli dan hasil BLINK, lalu simpan.');
  }catch(e){status('camera-status','Pemrosesan tidak berhasil: '+e.message);toast(e.message,true);processedPhoto=null;$('photo-after').removeAttribute('src')}
  finally{isBusy=false;$('snap').disabled=!stream;}
};
$('save-photo').onclick=()=>{if(!processedPhoto)return toast('Hasil foto belum tersedia.',true);downloadBlob(processedPhoto.blob,'BLINK-Photo-'+Date.now()+'.jpg')};

// Do not record the canvas at its default 300×150 dimensions before the first frame.
async function waitForFilteredFrame(){
  const initial=renderFrameCount,start=performance.now();
  while(renderFrameCount<=initial || !$('video-canvas').width || !$('video-canvas').height){
    if(performance.now()-start>3000)throw Error('Pratinjau video belum siap. Coba nyalakan kamera kembali.');
    await new Promise(ok=>requestAnimationFrame(ok));
  }
}
// Video export records the ACTUAL filtered canvas frames, not only a CSS preview.
function recordCanvas(durationMs=0){
  if(!stream)throw Error('Kamera belum dinyalakan.');if(!window.MediaRecorder)throw Error('MediaRecorder tidak tersedia pada WebView ini.');
  const c=$('video-canvas');if(!c.captureStream)throw Error('Canvas captureStream tidak tersedia.');
  if(!c.width||!c.height)throw Error('Frame video belum siap. Tunggu preview muncul.');
  const fps=Math.max(1,Math.min(Number($('video-fps').value),activeCaptureFps));
  // CPU color grading at 4K cannot sustain real-time FPS on many Android phones.
  // Reject unsupported combinations instead of producing a slideshow labeled 60 FPS.
  if(videoRenderer.stats().renderType.includes('CPU')&&(fps>30||Math.max(c.width,c.height)>1280))
    throw Error('GPU WebGL diperlukan untuk video resolusi/FPS tinggi. Pilih 720p 30 FPS agar video tetap lancar.');
  const capturedWidth=c.width,capturedHeight=c.height;
  const supportsManualFrame=typeof window.CanvasCaptureMediaStreamTrack!=='undefined' &&
    typeof window.CanvasCaptureMediaStreamTrack.prototype.requestFrame==='function';
  const output=c.captureStream(supportsManualFrame?0:fps);
  activeCanvasTrack=supportsManualFrame?output.getVideoTracks()[0]:null;
  for(const track of stream.getAudioTracks())output.addTrack(track);
  const pixels=c.width*c.height;
  // Higher quality requests; actual encoder bitrate and FPS are device dependent.
  let bitrate = pixels>=7000000 ? (fps>=60?42000000:28000000) : (fps>=60?14000000:9500000);
  if(pixels<1000000)bitrate=5000000;
  let created;
  try {created=createRecorder(output,{videoBitsPerSecond:bitrate});}
  catch(error){output.getVideoTracks().forEach(t=>t.stop());throw error;}
  const {recorder:rec,done}=created;
  const started=performance.now();const framesAtStart=renderFrameCount;
  const completed=done.then(blob=>({blob,mime:rec.mimeType,width:capturedWidth,height:capturedHeight,
    requestedFps:fps, approximateRenderFps:Math.max(0,Math.round((renderFrameCount-framesAtStart)*1000/Math.max(1,performance.now()-started))),
    requestedBitrate:created.encoderBitrate||bitrate,audioEnabled:Boolean(stream.getAudioTracks().length)}));
  completed.finally(()=>{if(activeCanvasTrack===output.getVideoTracks()[0])activeCanvasTrack=null;output.getVideoTracks().forEach(t=>t.stop());}).catch(()=>{});
  if(durationMs)setTimeout(()=>{if(rec.state!=='inactive')rec.stop()},durationMs);
  return {rec,done:completed};
}
$('video-record').onclick=async()=>{try{
  if($('video-quality').value==='2160' && accessLevel(user)<2){navigate('plans');throw Error('Video 4K tersedia pada BLINK Pro dan Pro Max.');}
  if($('video-quality').value==='1080' && accessLevel(user)<1){navigate('plans');throw Error('Video Full HD tersedia mulai BLINK Plus.');}
  if(isBusy)return;isBusy=true;
  await startCamera($('video-audio').checked);
  preparingRecord=true;
  await waitForFilteredFrame();
  const quality=Number($('video-quality').value), source=stream.getVideoTracks()[0].getSettings();
  if(quality===2160 && Math.min(source.width||0,source.height||0)<2160)
    throw Error('Kamera tidak menyediakan frame 4K asli. Pilih 1080p atau gunakan ekspor server untuk upscale.');
  if(quality===2160 && videoRenderer.stats().renderType.includes('CPU'))
    throw Error('4K dengan filter memerlukan GPU WebGL pada HP ini. Rekam 1080p lalu tingkatkan melalui server.');
  // Preflight the selected filter/resolution before committing a long recording.
  // A 30FPS label without enough actual frames produces the reported choppy video.
  const benchmarkStart=performance.now(),framesStart=renderFrameCount;
  await new Promise(ok=>setTimeout(ok,1000));
  const observed=(renderFrameCount-framesStart)*1000/Math.max(1,performance.now()-benchmarkStart);
  const minimum=Math.min(activeCaptureFps,Number($('video-fps').value))*0.85;
  if(observed<minimum)
    throw Error('Render '+Math.round(observed)+' FPS pada mode ini terlalu berat. Turunkan resolusi/FPS agar rekaman tidak patah-patah.');
  const {rec,done}=recordCanvas();recorder=rec;preparingRecord=false;
  $('video-record').disabled=true;$('video-finish').disabled=false;
  status('video-status','Sedang merekam filter '+$('video-preset').selectedOptions[0].text+' melalui '+videoRenderer.stats().renderType+'...');
  done.then(result=>{videoOutput=result;$('video-playback').src=URL.createObjectURL(result.blob);$('video-result').hidden=false;
    status('video-detail',`${result.width} × ${result.height} • permintaan maksimal ${result.requestedFps} FPS • renderer ≈${result.approximateRenderFps} FPS • target ${(result.requestedBitrate/1000000).toFixed(1)} Mbps • audio ${result.audioEnabled?'aktif':'nonaktif'} • ${readableBytes(result.blob.size)} • ${result.mime}`);
    status('video-status','Video diproses dengan filter sungguhan dan siap disimpan.');}).catch(e=>toast(e.message,true)).finally(()=>{isBusy=false;$('video-record').disabled=!stream;$('video-finish').disabled=true;});
}catch(e){preparingRecord=false;isBusy=false;toast(e.message,true)}};
$('video-finish').onclick=()=>{if(recorder?.state==='recording')recorder.stop()};
$('save-video').onclick=()=>{if(!videoOutput)return toast('Video belum selesai.',true);const ext=videoOutput.mime.includes('mp4')?'mp4':'webm';downloadBlob(videoOutput.blob,'BLINK-Video-'+Date.now()+'.'+ext)};
$('upscale-video-server').onclick=async()=>{
  if(!videoOutput?.blob?.size)return toast('Rekam video terlebih dahulu.',true);
  if(videoOutput.blob.size>18*1048576)return toast('Video lebih dari 18 MB. Rekam durasi lebih pendek untuk ekspor 4K server.',true);
  if(isBusy)return;
  isBusy=true;$('upscale-video-server').disabled=true;
  status('video-status','Mengirim video untuk ekspor 4K server. Tidak menggunakan AI video.');
  try{
    const reply=await api('/api/video/upscale-4k',{method:'POST',body:{video_base64:await encodeBase64(videoOutput.blob)}});
    if(!Number.isFinite(reply.width)||!Number.isFinite(reply.height)||Math.min(reply.width,reply.height)!==2160||reply.mime!=='video/mp4')throw Error('Server tidak mengembalikan video UHD yang terverifikasi.');
    const enhanced=decodeBase64Photo(reply.video_base64,'video/mp4');
    videoOutput={...videoOutput,blob:enhanced,mime:'video/mp4',width:reply.width,height:reply.height,serverUpscaled:true};
    $('video-playback').src=URL.createObjectURL(enhanced);
    status('video-detail',`UHD ${reply.width} × ${reply.height} • ${readableBytes(enhanced.size)} • ${reply.method} • piksel 4K hasil upscale, bukan restorasi AI`);
    status('video-status','Video 4K server selesai dan siap disimpan.');
  }catch(e){status('video-status','Ekspor 4K server gagal: '+e.message);toast(e.message,true);}
  finally{isBusy=false;$('upscale-video-server').disabled=false;}
};
// Real video quality engine. A full pretrained model must be present server-side
// for AI mode. Clarity mode is non-neural FFmpeg processing, labelled accurately.
$('video-enhance-submit').onclick=async()=>{
  if(!videoOutput?.blob?.size)return toast('Rekam video terlebih dahulu.',true);
  if(videoOutput.blob.size>18*1048576)return toast('Video maksimal 18 MB untuk peningkatan server.',true);
  if(localMode())return toast('Peningkatan video server memerlukan server BLINK HTTPS yang aktif.',true);
  if(isBusy)return;
  const mode=$('video-enhance-mode').value,resolution=$('video-enhance-resolution').value;
  if((mode==='realesrgan'||resolution==='2160')&&accessLevel(user)<2){navigate('plans');return toast('Fitur ini membutuhkan BLINK Pro.',true);}
  if(resolution==='4320'&&accessLevel(user)<3){navigate('plans');return toast('Ekspor 8K memerlukan Pro Max dan server 8K.',true);}
  isBusy=true;$('video-enhance-submit').disabled=true;
  status('video-enhance-note',mode==='realesrgan'?'Memproses setiap frame dengan model Real-ESRGAN terlatih di GPU…':'Mengurangi noise temporal dan mempertajam frame pada server…');
  try{
    if(mode==='realesrgan'){
      const st=await api('/api/ai/status',{auth:false});
      if(st.engine!=='RealESRGAN_x4plus'||!st.trained_model_ready||st.device!=='cuda')throw Error('Bobot AI asli dan GPU BLINK belum siap. Tidak ada token terpotong.');
    }
    const reply=await api('/api/video/enhance',{method:'POST',body:{video_base64:await encodeBase64(videoOutput.blob),mode,resolution,strength:$('video-enhance-strength').value},timeoutMs:mode==='realesrgan'?900000:180000});
    if(!reply.video_base64||reply.mime!=='video/mp4'||reply.width<320||reply.height<180)throw Error('Server tidak mengembalikan file video yang benar.');
    if(mode==='realesrgan'&&(!reply.model_sha256||reply.method!=='RealESRGAN_x4plus trained per-frame'))throw Error('Bukti inferensi AI tidak ditemukan pada hasil server.');
    const enhanced=decodeBase64Photo(reply.video_base64,'video/mp4');
    if(!enhanced.size)throw Error('Hasil video kosong.');
    videoOutput={...videoOutput,blob:enhanced,mime:'video/mp4',width:reply.width,height:reply.height,serverMethod:reply.method};
    $('video-playback').src=URL.createObjectURL(enhanced);
    status('video-detail',`${reply.width} × ${reply.height} • ${Number(reply.fps).toFixed(2)} FPS • ${readableBytes(enhanced.size)} • ${reply.method}`);
    status('video-enhance-note',`Selesai: ${reply.method}. Simpan hasil melalui tombol Simpan Video.`);
    if(mode==='realesrgan')void refreshMe().catch(()=>{});
  }catch(e){status('video-enhance-note','Pemrosesan tidak berhasil: '+e.message);toast(e.message,true);}
  finally{isBusy=false;$('video-enhance-submit').disabled=false;}
};
$('live-capture').onclick=async()=>{
  if(isBusy)return;isBusy=true;
  try{await startCamera(true);let still=await captureStill($('camera-feed'));
    if(digitalZoom>1.001)still={...still,blob:await cropZoomedPhoto(still.blob,digitalZoom)};
    const {rec,done}=recordCanvas(3000);status('live-status','Merekam gerakan 3 detik...');
    const result=await processStill(still.blob,'sharp','live-status');const motion=await done;
    livePhoto=result;liveMotion=motion;$('live-picture').src=URL.createObjectURL(result.blob);$('live-motion').src=URL.createObjectURL(motion.blob);$('live-result').hidden=false;
    status('live-status','Live Photo selesai: foto diproses, video gerakan direkam.');
  }catch(e){status('live-status','Live Photo gagal: '+e.message);toast(e.message,true)}finally{isBusy=false;}
};
$('live-save-photo').onclick=()=>{if(livePhoto)downloadBlob(livePhoto.blob,'BLINK-Live-'+Date.now()+'.jpg')};
$('live-save-motion').onclick=()=>{if(liveMotion)downloadBlob(liveMotion.blob,'BLINK-Motion-'+Date.now()+(liveMotion.mime.includes('mp4')?'.mp4':'.webm'))};

// Permanent BLINK catalog. Price/entitlements are mirrored by the server.
async function loadPlans(){
 const root=$('plans-list');root.replaceChildren();
 let remote={}; if(!localMode()){
   try{remote=Object.fromEntries((await api('/api/plans',{auth:false})).map(p=>[p.id,p]));}catch(e){console.warn('Catalog server unavailable:',e.message);}
 }
 for(const def of BLINK_PLANS){
   const plan=remote[def.id]||def,enabled=def.id==='free'||(!localMode()&&!!remote[def.id]&&!!remote[def.id].enabled);
   const card=document.createElement('article');card.className='plan-card'+(def.featured?' featured':'')+(user?.tier===def.id?' subscribed':'');
   const top=document.createElement('div');top.className='plan-card-top';
   const b=document.createElement('span');b.className='plan-kicker';b.textContent=def.id==='free'?'GRATIS':def.featured?'PALING POPULER':'BLINK PREMIUM';top.append(b);
   if(user?.tier===def.id){const current=document.createElement('span');current.className='plan-current';current.textContent='Paket aktif';top.append(current);} card.append(top);
   const h=document.createElement('h3');h.textContent=def.name;card.append(h);
   const subtitle=document.createElement('p');subtitle.className='plan-subtitle';subtitle.textContent=def.subtitle;card.append(subtitle);
   const price=document.createElement('div');price.className='plan-price';price.textContent=money(plan.price??def.price);const month=document.createElement('small');month.textContent=def.id==='free'?'/selamanya':'/bulan';price.append(month);card.append(price);
   const list=document.createElement('ul');list.className='plan-benefits';for(const [i,feat] of def.features.entries()){const li=document.createElement('li');li.textContent=(i===0&&def.id!=='free')?`${plan.tokens} token premium / ${plan.days} hari`:feat;list.append(li)}card.append(list);
   const buy=document.createElement('button');buy.className='button '+(def.featured?'primary':'plan-button');
   buy.textContent=def.id==='free'?'Paket Gratis':localMode()?'Hubungkan BLINK untuk Berlangganan':!enabled?'Tidak tersedia':'Pilih '+def.name;
   buy.disabled=def.id==='free'||(!enabled&&!localMode());
   buy.onclick=()=>{if(localMode())return toast('Langganan membutuhkan koneksi server BLINK dan verifikasi QRIS oleh admin.',true);
      chosenPlan=plan;status('selected-plan',def.name);status('selected-price',money(plan.price));navigate('payment');};
   card.append(buy);root.append(card);
 }
}
async function refreshOrders(){if(localMode()||!token)return;try{const orders=await api('/api/orders/mine');const root=$('payment-history');root.replaceChildren();for(const o of orders){const d=document.createElement('div');d.textContent=`Order #${o.id} • ${o.plan_id.toUpperCase()} • ${o.status} • ${new Date(o.created*1000).toLocaleString('id-ID')}`;root.append(d)}}catch(e){status('payment-status',e.message)}}
$('submit-payment').onclick=async()=>{
  if(localMode())return toast('Pembayaran QRIS memerlukan server BLINK yang terhubung.',true);
  if(!chosenPlan)return toast('Pilih paket dari katalog terlebih dahulu.',true);
  const file=$('payment-proof').files[0];if(!file||file.size>6*1048576)return toast('Unggah JPG/PNG maksimal 6 MB.',true);
  if(!['image/png','image/jpeg'].includes(file.type))return toast('Bukti harus JPG atau PNG.',true);
  try{const buffer=await file.arrayBuffer(),bytes=new Uint8Array(buffer);let raw='';for(let i=0;i<bytes.length;i+=0x8000)raw+=String.fromCharCode(...bytes.subarray(i,i+0x8000));
    const result=await api('/api/orders',{method:'POST',body:{plan:chosenPlan.id,proof_base64:btoa(raw),reference:$('payment-ref').value}});
    status('payment-status',`Order #${result.id} terkirim. Menunggu keputusan admin. Tidak aktif otomatis.`);toast('Bukti pembayaran diterima untuk pemeriksaan manual.');await refreshOrders();
  }catch(e){status('payment-status',e.message);toast(e.message,true)}
};
// Refresh server-side balances and payment decisions while user APK is open.
setInterval(()=>{if((token||hasDeviceSession())&&$('studio').classList.contains('show')){void refreshMe().catch(()=>{});if($('page-payment').classList.contains('active'))void refreshOrders();}},4000);
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&(token||hasDeviceSession()))void refreshMe().catch(()=>{});});
window.addEventListener('pagehide',stopCamera);

// Returning users: validate the saved session, then go straight to camera.
if(token||hasDeviceSession())void enterApp();
