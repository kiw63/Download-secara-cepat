/** BLINK V6.1 native-pixel detail engine (non-generative). No invented image features.
 * Uses a Gaussian 3x3 luma neighbourhood, adaptive noise suppression and
 * restrained luminance sharpening without changing chromatic detail per-channel.
 * Input patch includes a one-pixel halo on every available side.
 */
export const clamp=(x,min=0,max=255)=>Math.max(min,Math.min(max,x));
export function enhancePhotoPatch(src,width,height,{params,tint,strength=1,detail=1,
  neural=null,neuralWidth=0,neuralHeight=0,offsetX=0,offsetY=0,outWidth=width,outHeight=height}={}){
  if(!params||!tint)throw new Error('Profil foto tidak valid');
  if(width<1||height<1||src.length!==width*height*4)throw new Error('Pixel foto tidak valid');
  strength=clamp(Number(strength)||0,0,1.5);
  const n=width*height,tone=new Uint8ClampedArray(src.length),lum=new Float32Array(n);
  for(let p=0;p<n;p++){
    const i=p*4;let r=src[i]/255,g=src[i+1]/255,b=src[i+2]/255;
    r=Math.pow(Math.min(1,r*params.gain),params.gamma);
    g=Math.pow(Math.min(1,g*params.gain),params.gamma);
    b=Math.pow(Math.min(1,b*params.gain),params.gamma);
    const y=.2126*r+.7152*g+.0722*b;
    r=(y+(r-y)*params.sat-.5)*params.contrast+.5;
    g=(y+(g-y)*params.sat-.5)*params.contrast+.5;
    b=(y+(b-y)*params.sat-.5)*params.contrast+.5;
    tone[i]=clamp(255*r*tint[0]);tone[i+1]=clamp(255*g*tint[1]);tone[i+2]=clamp(255*b*tint[2]);tone[i+3]=255;
    lum[p]=.2126*src[i]+.7152*src[i+1]+.0722*src[i+2];
  }
  const out=new Uint8ClampedArray(src.length);
  // Sharpen original luminance instead of tonalized RGB to prevent color halos.
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const p=y*width+x,i=p*4;
    const xl=Math.max(0,x-1),xr=Math.min(width-1,x+1);
    const yt=Math.max(0,y-1),yb=Math.min(height-1,y+1);
    const top=yt*width,mid=y*width,bot=yb*width;
    const smooth=(lum[top+xl]+2*lum[top+x]+lum[top+xr]+2*lum[mid+xl]+4*lum[p]+2*lum[mid+xr]+lum[bot+xl]+2*lum[bot+x]+lum[bot+xr])/16;
    const hf=lum[p]-smooth;
    const abs=Math.abs(hf);
    // Shallow source noise should not become speckles and halo edges are limited.
    const noise=(params.denoise||0)*Math.max(0,1-abs/9);
    const high=abs<1.4?0:abs>38?Math.sign(hf)*38:hf;
    const sharpen=high*clamp(detail,0,2)*Math.max(.20,Math.min(1,abs/6));
    const residual=neural?neural[p]-128:0;
    const adjustment=clamp(sharpen - hf*noise + residual,-22,22)*strength;
    for(let c=0;c<3;c++)out[i+c]=clamp(src[i+c]+(tone[i+c]-src[i+c])*strength+adjustment);
    out[i+3]=255;
  }
  return out;
}
