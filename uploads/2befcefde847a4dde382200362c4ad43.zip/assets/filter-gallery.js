/** BLINK own preset gallery, not copies of licensed CapCut filter assets. */
import {gradePixels, filterUniforms} from './video-renderer.js';
const P={
  sharp:['Auto Sharp','Esensial',0],ultra:['Detail Max','Esensial',2],clean:['Natural HD','Esensial',0],night:['Night Recovery','Malam',1],vivid:['Vibrant Color','Warna',0],portrait:['Portrait','Potret',0],analog:['Analog Film','Film',1],retro:['Retro Warm','Film',1],blackwhite:['Black & White','Film',0],pastel:['Pastel Soft','Warna',1],golden:['Golden Glow','Warna',1],icy:['Icy Clarity','Warna',2],moody:['Moody Dark','Film',2],teal:['Teal Cinema','Film',2],travel:['Travel Color','Warna',0],food:['Food Bright','Warna',1],beauty:['Soft Beauty','Potret',1],glow:['Dream Glow','Potret',2],nightblue:['Night Blue','Malam',2],street:['Street Contrast','Film',2],fresh:['Fresh Color','Warna',0]
};
const V_GROUP = {
  natural:'Esensial',cinematic:'Film',sunset:'Hangat',clearblue:'Dingin',sicily:'Hangat',dramatic:'Film',vintage:'Film',retro:'Film',noir:'Hitam Putih',mono_soft:'Hitam Putih',tealorange:'Film',golden:'Hangat',pastel:'Lembut',mint:'Dingin',rose:'Lembut',coffee:'Hangat',moody:'Film',nightcity:'Malam',neon:'Neon',icy:'Dingin',ocean:'Dingin',forest:'Alam',travel:'Alam',portraitfilm:'Potret',softfilm:'Lembut',vlogbright:'Esensial',foodpop:'Warna',urban:'Film',desert:'Hangat',lightleak:'Film',lavender:'Lembut',bluehour:'Malam',amber:'Hangat',silver:'Hitam Putih',pearlescent:'Lembut',emerald:'Alam',peach:'Lembut',cyberpunk:'Neon',tungsten:'Hangat',punchy:'Warna',mist:'Lembut',classic:'Film',coral:'Hangat',deepsea:'Dingin',noirhigh:'Hitam Putih'
};
const V_NAMES={natural:'Natural',cinematic:'Cinematic',sunset:'Senja Sinematik',clearblue:'Clear Blue',sicily:'Sicily Warm',dramatic:'Dramatic',vintage:'Vintage Film',retro:'Retro 90s',noir:'Noir',mono_soft:'Soft Mono',tealorange:'Teal & Orange',golden:'Golden Hour',pastel:'Pastel Dream',mint:'Mint Breeze',rose:'Rose Glow',coffee:'Coffee Mood',moody:'Moody Dark',nightcity:'Night City',neon:'Neon Pop',icy:'Icy Cold',ocean:'Ocean Blue',forest:'Forest Green',travel:'Travel Daylight',portraitfilm:'Portrait Film',softfilm:'Soft Film',vlogbright:'Vlog Bright',foodpop:'Food Pop',urban:'Urban Steel',desert:'Desert Warm',lightleak:'Light Leak',lavender:'Lavender Haze',bluehour:'Blue Hour',amber:'Amber Film',silver:'Silver Mono',pearlescent:'Pearl Soft',emerald:'Emerald',peach:'Peach Bloom',cyberpunk:'Cyberpunk',tungsten:'Tungsten',punchy:'Punchy HDR',mist:'Morning Mist',classic:'Classic Film',coral:'Coral Glow',deepsea:'Deep Sea',noirhigh:'Noir High'};
export const PHOTO_PRESETS=Object.entries(P).map(([id,[name,category,minTier]])=>({id,name,category,minTier}));
export const VIDEO_PRESETS=Object.keys(V_GROUP).map((id,i)=>({id,name:V_NAMES[id]||id,category:V_GROUP[id],minTier:i<8?0:i<20?1:i<36?2:3}));
function sampleCanvas(){
 const c=document.createElement('canvas'); c.width=120;c.height=96;const x=c.getContext('2d');
 const sky=x.createLinearGradient(0,0,0,96);sky.addColorStop(0,'#4ba4df');sky.addColorStop(.55,'#e5b497');sky.addColorStop(1,'#275b68');x.fillStyle=sky;x.fillRect(0,0,120,96);
 x.fillStyle='#fde4ac';x.beginPath();x.arc(90,27,14,0,7);x.fill();
 x.fillStyle='#286a7f';x.beginPath();x.moveTo(0,73);x.lineTo(37,43);x.lineTo(65,73);x.lineTo(86,52);x.lineTo(120,78);x.lineTo(120,96);x.lineTo(0,96);x.fill();
 x.fillStyle='#18394d';x.beginPath();x.moveTo(0,87);x.lineTo(33,64);x.lineTo(62,93);x.lineTo(120,80);x.lineTo(120,96);x.lineTo(0,96);x.fill();
 return c;
}
const PHOTO_CSS={sharp:'contrast(1.3) saturate(1.1)',ultra:'contrast(1.5) saturate(1.3)',clean:'contrast(1.08)',night:'brightness(1.3) contrast(1.2)',vivid:'saturate(1.6) contrast(1.2)',portrait:'brightness(1.07) saturate(.95)',analog:'sepia(.4) saturate(.8)',retro:'sepia(.6) contrast(1.3)',blackwhite:'grayscale(1) contrast(1.4)',pastel:'brightness(1.2) saturate(.7)',golden:'sepia(.55) saturate(1.3)',icy:'hue-rotate(15deg) contrast(1.2)',moody:'brightness(.7) contrast(1.4)',teal:'hue-rotate(32deg) contrast(1.4)',travel:'saturate(1.5)',food:'saturate(1.5) brightness(1.1)',beauty:'brightness(1.2)',glow:'brightness(1.2) contrast(.85)',nightblue:'hue-rotate(40deg) brightness(.8)',street:'contrast(1.5) saturate(.8)',fresh:'saturate(1.4) brightness(1.1)'};
function thumb(p,kind){const c=sampleCanvas();if(kind==='photo'){const o=document.createElement('canvas');o.width=120;o.height=96;const ctx=o.getContext('2d');ctx.filter=PHOTO_CSS[p.id]||'none';ctx.drawImage(c,0,0);return o.toDataURL('image/jpeg',.76);}const x=c.getContext('2d');const pixels=x.getImageData(0,0,120,96);gradePixels(pixels.data,120,96,filterUniforms(p.id,130));x.putImageData(pixels,0,0);return c.toDataURL('image/jpeg',.76);}
export function createFilterGallery({kind,containerId,categoriesId,select,onSelect,tier=0}){
 const presets=kind==='photo'?PHOTO_PRESETS:VIDEO_PRESETS;
 const gallery=document.getElementById(containerId),cats=document.getElementById(categoriesId);
 let active='Semua',level=tier,images=new Map();
 function draw(){gallery.replaceChildren();for(const p of presets.filter(p=>active==='Semua'||p.category===active)){
   const allowed=p.minTier<=level;const item=document.createElement('button');item.type='button';item.className='filter-tile'+(select.value===p.id?' selected':'')+(allowed?'':' locked');item.dataset.filter=p.id;
   const frame=document.createElement('span');frame.className='filter-thumb';const im=new Image();if(!images.has(p.id))images.set(p.id,thumb(p,kind));im.src=images.get(p.id);im.alt='';im.loading='lazy';frame.append(im);
   if(!allowed){const lock=document.createElement('span');lock.className='filter-lock';lock.textContent=['FREE','PLUS','PRO','MAX'][p.minTier];frame.append(lock);}
   const name=document.createElement('span');name.className='filter-label';name.textContent=p.name;item.append(frame,name);
   item.onclick=()=>{if(!allowed){onSelect(p,true);return;}select.value=p.id;select.dispatchEvent(new Event('change',{bubbles:true}));draw();onSelect(p,false);};gallery.append(item);
 }}
 for(const cat of ['Semua',...new Set(presets.map(p=>p.category))]){const b=document.createElement('button');b.type='button';b.className='category-chip'+(cat===active?' active':'');b.textContent=cat;b.onclick=()=>{active=cat;cats.querySelectorAll('button').forEach(b=>b.classList.toggle('active',b.textContent===cat));draw()};cats.append(b)}
 draw();return {refresh:draw,setTier(next){level=next;draw();},presets};
}
