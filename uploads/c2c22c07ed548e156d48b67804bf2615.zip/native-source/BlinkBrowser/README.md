# Blink Browser v3.0 — Chromium WebView Android native

**Ini sumber aplikasi Android native, bukan ZIP situs HTML.** Jangan unggah ke converter HTML-to-APK yang mengharuskan `index.html`: converter tersebut tidak dapat mengompilasi WebView native, DownloadManager, atau pemisahan proses Samaran. Untuk APK gunakan Android Studio / GitHub Actions di bawah.

## Perbaikan utama v3

| Area | Implementasi nyata di source | Batasan yang harus dipahami |
|---|---|---|
| Jelajah web | `android.webkit.WebView` memakai penyedia Android System WebView berbasis Chromium; JavaScript, DOM storage, tautan eksternal, popup bertindakan pengguna, fullscreen dan upload melalui pemilih file Android. Menu **Kontrol Situs → Mode kompatibilitas** dapat mencoba user-agent standar Chrome dari Chromium yang terpasang. | Ini **bukan binary Chrome** dan tidak dapat memaksa server/Google OAuth/ISP membuka situs yang menolak WebView atau memblokir akses. Pencarian tidak disaring secara khusus oleh Blink, tetapi mesin pencari tetap menerapkan aturan sendiri. |
| Banyak tab | Hingga **40 tab** normal / privat; hanya **8 WebView hidup** pada satu proses, tab lama memakai `saveState/restoreState` untuk mengurangi tekanan RAM. | Halaman/tab yang ditangguhkan dapat perlu reload dan status dinamis seperti form belum tentu dipertahankan. Keberhasilan bergantung RAM dan perangkat. |
| Mode Samaran | Activity/process Android **`:blink_private`**, penyimpanan Chromium dengan suffix terpisah, folder profil lama dibersihkan pada awal proses baru, cookie dan WebStorage dibersihkan sebelum navigasi pertama; tidak menyimpan histori atau sesi tab privat ke prefs Blink. | Unduhan Samaran tetap disimpan di Downloads publik, bookmark yang sengaja disimpan tetap terlihat, dan Samaran **tidak menyembunyikan aktivitas dari situs/ISP**. Android OS/cache eksternal tidak dijamin tanpa jejak. |
| Download HTTP/HTTPS | Android `DownloadManager` melakukan transfer latar belakang, menunjukkan notifikasi, menerima cookie, User-Agent dan Referer; file disimpan dalam `Download/`. Menu **Download Blink** menampilkan status, progres, buka/hapus/batalkan. | Login situs, token, DRM, streaming dan aturan server tetap dapat memengaruhi unduhan. DownloadManager tidak mendukung setiap alur POST/auth interaktif. |
| Download `blob:` / `data:` | Melalui kode halaman dengan `evaluateJavascript` (tidak ada `addJavascriptInterface` yang terekspos ke situs), fetch file lokal halaman, baca per 256 KiB, stream ke Android MediaStore `Download/Blink/`, tangani beberapa transfer paralel. Download Blink menampilkan status berkas, buka/hapus/batalkan. Menu tekan-lama tautan/gambar dapat memulai download. | Maks. **128 MiB per file**. Blob di iframe lintas-origin, unduhan yang tidak memicu DownloadListener, dan resource DRM bisa gagal. Transfer yang berhenti di tengah halaman akan dibatalkan/berisiko tertunda sampai timeout. |

### Privasi dan keamanan

- Safe Browsing aktif, sertifikat TLS tidak valid **tidak** dilewati, akses file lokal JavaScript dibatasi.
- Jika mode kompatibilitas aktif, user-agent dapat sedikit berbeda agar situs yang mendeteksi WebView lebih mudah diakses. **Tidak menjamin** situs membuka atau login.
- Samaran mengisolasi profil web dari tab normal; klik **Samaran** dari beranda/menu untuk membukanya. PrivateActivity menjalankan kode WebView di proses berbeda.
- Browser tidak menjanjikan penghindaran filter jaringan/perangkat, bypass blokir pemerintah, atau akses ke konten yang sengaja dibatasi server.

## Membuat APK dari GitHub (bisa dari HP)

Paket `BlinkAndroid_Source_v3.zip` dan file workflow `BLINK_V3_GITHUB_BUILD.yml` disiapkan terpisah.

1. Buat repository di GitHub.
2. Unggah **file ZIP** `BlinkAndroid_Source_v3.zip` ke ROOT repository (jangan diekstrak bila memakai workflow zip).
3. Di GitHub pilih **Add file → Create new file**, nama file **`.github/workflows/build.yml`**. Tempel seluruh isi `BLINK_V3_GITHUB_BUILD.yml` dan commit.
4. Pilih tab **Actions → Build Blink v3 from source ZIP → Run workflow**. Workflow mengunduh JDK 17, Android SDK 35 dan Gradle 8.9, menjalankan tes JVM lalu `gradle assembleDebug`.
5. Jika semua langkah berhasil, unduh artifact **`Blink-v3-native-debug-APK`**, ekstrak ZIP artifact, dan instal `app-debug.apk` di Android 10+.

> Debug APK ditandatangani otomatis untuk **pengujian**, bukan Play Store release. Jika GitHub Actions gagal, periksa langkah gagal dan lognya; source ini belum diverifikasi lewat build Android SDK/emulator di lingkungan pembuat.

## Membangun dari PC Android Studio

- Perlu JDK 17, SDK Platform 35, Gradle 8.9, Android Gradle Plugin 8.7.3.
- Ekstrak `BlinkAndroid_Source_v3.zip`, pilih direktori `BlinkBrowser` yang berisi `settings.gradle`, lalu jalankan Gradle `assembleDebug`.
- Debug APK biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.
- Proyek tidak menyertakan `gradle-wrapper.jar`; workflow GitHub memakai Gradle 8.9 yang disiapkan dari action resmi.

## Pemeriksaan yang benar-benar dijalankan di sini

- `javac` dan unit test Java mandiri untuk URL serta sanitasi nama berkas.
- Parser Java mengonfirmasi tidak ada kesalahan **sintaks**, tanpa dependensi Android.
- Semua Android XML dibaca oleh parser XML.
- Struktur ZIP dan checksum arsip diverifikasi.

**Belum selesai diverifikasi:** kompilasi APK di Android SDK, peluncuran Android 10–16, kompatibilitas login berbagai situs, unduhan blob dari WebView nyata, data Samaran selama lifecycle Android, tab restore setelah low memory, dan unduhan background dari situs autentikasi. Jangan menyebut semua ini "100% teruji" sebelum tes perangkat.

## File kunci

- `app/src/main/java/com/blink/browser/MainActivity.java` — browser, tab, menu, HTTP downloads.
- `app/src/main/java/com/blink/browser/PrivateActivity.java` — proses/profil Samaran.
- `app/src/main/java/com/blink/browser/BlobDownloader.java` — streaming blob/data ke Downloads.
- `app/src/main/java/com/blink/browser/DownloadCenter.java` — daftar unduhan, status, buka/hapus/batalkan.
- `app/src/main/java/com/blink/browser/UrlResolver.java` — parser alamat/pencarian.
- `qa/browser-test.html` — halaman manual untuk uji blob, data, tab, input upload (dihost di web server sendiri selama QA).
