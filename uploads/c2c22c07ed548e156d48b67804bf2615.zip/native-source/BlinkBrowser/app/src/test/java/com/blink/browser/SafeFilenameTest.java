package com.blink.browser;

public final class SafeFilenameTest {
    public static void main(String[] args) {
        verify("../../secret.pdf", "_.._secret.pdf");
        verify("photo:album?.jpg", "photo_album_.jpg");
        verify(null, "download.bin");
        verify("...", "download.bin");
        verify("  report.pdf  ", "report.pdf");
        String longName = "X".repeat(200);
        if (SafeFilename.sanitize(longName).length() != 110) throw new AssertionError();
        System.out.println("Filename sanitizer tests passed.");
    }
    static void verify(String input, String expected) {
        String value = SafeFilename.sanitize(input);
        if (!value.equals(expected)) throw new AssertionError("Expected " + expected + ", got " + value);
    }
}
