package com.blink.browser;

/** Dependency-free sanity test: java -ea com.blink.browser.UrlResolverTest */
public final class UrlResolverTest {
    public static void main(String[] args) {
        check("", "about:blank");
        check("  about:blank ", "about:blank");
        check("google.com", "https://google.com");
        check("example.com/path?q=1", "https://example.com/path?q=1");
        check("https://example.com/", "https://example.com/");
        check("http://example.com", "http://example.com");
        check("localhost:3000/path", "http://localhost:3000/path");
        check("192.168.1.2:8080", "http://192.168.1.2:8080");
        check("cuaca hari ini", "https://www.google.com/search?q=cuaca+hari+ini");
        check("javascript:alert(1)", "https://www.google.com/search?q=javascript%3Aalert%281%29");
        assert !UrlResolver.isWebUrl("javascript:alert(1)");
        assert UrlResolver.isWebUrl("https://wikipedia.org");
        System.out.println("URL resolver tests passed.");
    }
    private static void check(String input, String expected) {
        String actual = UrlResolver.resolve(input);
        if (!expected.equals(actual)) throw new AssertionError(input + ": " + actual);
    }
}
